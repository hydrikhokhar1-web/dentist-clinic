# Nura Dental Studio

Premium PHP 8 / MySQL dental clinic management website for XAMPP. It includes a public clinic site, secure patient portal, professional admin panel, database-driven doctors/services/fees, live appointment availability and a reusable footer map.

## Install on XAMPP

1. Copy the complete `dental-clinic` folder to `C:\xampp\htdocs\dental-clinic`.
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Open phpMyAdmin at `http://localhost/phpmyadmin/`.
4. Select **Import**, choose `database/database.sql` from this project, and run the import.
5. Open `http://localhost/dental-clinic/`.

The SQL file creates the `dental_clinic` database and inserts the six requested clinicians, eight services, fee data, schedules, settings and an administrator.

## Demo administrator

- URL: `http://localhost/dental-clinic/admin/login.php`
- Email: `admin@nura.dental`
- Password: `Admin@12345`

Patients create their own account through **Patient sign in → Create a patient account**.

## Configuration

- Database connection: `config/database.php`
- Clinic details and social links: **Admin → Settings**
- Doctor images: **Admin → Clinicians**, or replace URLs with images in `assets/images/`
- Service images: **Admin → Services**, or replace URLs with images in `assets/images/`
- Intro video: place `clinic-intro.mp4` in `assets/video/`. The homepage has a graceful animated fallback if this file is absent.

## Security included

- PDO prepared statements
- Password hashing and verification
- Regenerated session IDs on login
- CSRF protection on state-changing forms
- Server-side validation and output escaping
- Role-protected patient and admin routes
- A database-level unique clinician/date/time appointment constraint

## Important note

Importing `database/database.sql` resets the `dental_clinic` database. Back up a live database before importing it into production.
