<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';
$feeRows = $pdo->query('SELECT * FROM fees ORDER BY category, id')->fetchAll();
$fees = [];
foreach ($feeRows as $fee) { $fees[$fee['category']][] = $fee; }
$pageTitle = 'Treatment fees';
require __DIR__ . '/partials/header.php';
?>
<main>
    <section class="page-banner" style="--banner-image:url('https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&w=1600&q=85')"><div class="container"><span class="eyebrow">Treatment fees</span><h1>Clear fees. Confident decisions.</h1><p>We believe treatment costs should be easy to understand before your care begins.</p></div></section>
    <section class="section"><div class="container"><div class="section-head reveal"><span class="eyebrow">Our pricing</span><h2>Starting fees for our most requested care.</h2><p>Your clinician will always explain a personalised plan and any associated costs before treatment.</p></div><div class="price-grid">
        <?php foreach ($fees as $category => $items): ?>
            <article class="card price-card reveal"><h2><?= e($category) ?></h2><?php foreach ($items as $fee): ?><div class="price-line"><span><?= e($fee['name']) ?><small><?= e($fee['duration'] ?? '') ?></small></span><strong><?= money($fee['price']) ?></strong></div><?php endforeach; ?></article>
        <?php endforeach; ?>
    </div><div class="notice"><i class="fa-solid fa-circle-info"></i><span>Final treatment costs can vary after your consultation because each patient’s needs, materials and clinical plan are individual.</span></div></div></section>
</main>
<?php require __DIR__ . '/partials/footer.php'; ?>
