<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';
$doctorId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$statement = $pdo->prepare('SELECT * FROM dentists WHERE id = ? LIMIT 1');
$statement->execute([$doctorId]);
$doctor = $statement->fetch();
if (!$doctor) { redirect('doctors.php'); }
$pageTitle = $doctor['name'];
require __DIR__ . '/partials/header.php';
?>
<main>
    <section class="page-banner" style="--banner-image:url('<?= e($doctor['image']) ?>')"><div class="container"><span class="eyebrow">Meet your clinician</span><h1><?= e($doctor['name']) ?></h1><p><?= e($doctor['specialization']) ?></p></div></section>
    <section class="section"><div class="container detail-grid"><img class="detail-image reveal" src="<?= e($doctor['image']) ?>" alt="<?= e($doctor['name']) ?>"><div class="reveal"><span class="eyebrow"><?= e($doctor['qualification']) ?></span><h2><?= e($doctor['specialization']) ?></h2><p class="muted"><?= e($doctor['biography']) ?></p><div class="detail-meta"><div><span>Experience</span><strong><?= e($doctor['experience']) ?></strong></div><div><span>Consultation</span><strong><?= money($doctor['consultation_fee']) ?></strong></div><div><span>Working days</span><strong><?= e($doctor['working_days']) ?></strong></div><div><span>Hours</span><strong><?= e($doctor['working_hours']) ?></strong></div></div><a class="button button-primary" href="<?= app_url('appointment.php?dentist=' . (int) $doctor['id']) ?>">Book with <?= e($doctor['name']) ?> <i class="fa-solid fa-arrow-right"></i></a></div></div></section>
</main>
<?php require __DIR__ . '/partials/footer.php'; ?>
