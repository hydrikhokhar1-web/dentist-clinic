<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';
$doctors = $pdo->query('SELECT * FROM dentists ORDER BY id')->fetchAll();
$pageTitle = 'Our clinicians';
require __DIR__ . '/partials/header.php';
?>
<main>
    <section class="page-banner" style="--banner-image:url('https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1600&q=85')"><div class="container"><span class="eyebrow">Our clinicians</span><h1>Expertise you can feel comfortable with.</h1><p>Six dedicated dentists, each bringing specialised knowledge and a shared commitment to patient-first care.</p></div></section>
    <section class="section"><div class="container"><div class="doctors-grid">
        <?php foreach ($doctors as $doctor): ?>
            <article class="card doctor-card reveal"><div class="doctor-photo"><img src="<?= e($doctor['image']) ?>" alt="<?= e($doctor['name']) ?>" loading="lazy"></div><div class="doctor-info"><h3><?= e($doctor['name']) ?></h3><p><?= e($doctor['specialization']) ?></p><div class="doctor-actions"><a class="button button-outline" href="<?= app_url('doctor-details.php?id=' . (int) $doctor['id']) ?>">View profile</a><a class="button button-soft" href="<?= app_url('appointment.php?dentist=' . (int) $doctor['id']) ?>">Book visit</a></div></div></article>
        <?php endforeach; ?>
    </div></div></section>
</main>
<?php require __DIR__ . '/partials/footer.php'; ?>
