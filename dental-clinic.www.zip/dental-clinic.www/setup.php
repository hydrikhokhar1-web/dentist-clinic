<?php
/**
 * Database Setup/Migration Script
 * Run this once to set up the database properly
 */
declare(strict_types=1);

require_once __DIR__.'/config/database.php';

try {
    echo "<h1>🔧 Database Setup</h1>";
    
    // Check if full_name column exists in admins table
    $stmt = $pdo->query("DESCRIBE admins");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
    
    if (!in_array('full_name', $columns)) {
        echo "Adding 'full_name' column to admins table...<br>";
        $pdo->exec("ALTER TABLE admins ADD COLUMN full_name VARCHAR(120) NOT NULL DEFAULT 'Administrator' AFTER id");
        echo "✓ Column 'full_name' added successfully.<br>";
    } else {
        echo "✓ 'full_name' column already exists in admins table.<br>";
    }
    
    // Verify admin user exists
    $adminCount = $pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
    if ($adminCount == 0) {
        echo "Creating default admin user...<br>";
        $hash = password_hash('admin123', PASSWORD_BCRYPT);
        $pdo->prepare("INSERT INTO admins(full_name, email, password_hash) VALUES(?, ?, ?)")
            ->execute(['System Administrator', 'admin@smilecare.com', $hash]);
        echo "✓ Default admin created (Email: admin@smilecare.com, Password: admin123)<br>";
    } else {
        echo "✓ Admin user(s) already exist.<br>";
    }
    
    // Check all required tables
    $requiredTables = ['users', 'admins', 'dentists', 'services', 'fees', 
                       'doctor_schedules', 'appointments', 'reviews', 'contact_messages', 'settings'];
    
    echo "<br><h3>Table Status:</h3>";
    $stmt = $pdo->query("SHOW TABLES");
    $existingTables = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
    
    foreach ($requiredTables as $table) {
        if (in_array($table, $existingTables)) {
            echo "✓ <strong>$table</strong> - OK<br>";
        } else {
            echo "✗ <strong>$table</strong> - MISSING<br>";
        }
    }
    
    echo "<br><h3>✓ Database setup complete!</h3>";
    echo "<p><a href='admin/login.php'>Go to Admin Login →</a></p>";
    
} catch (Exception $e) {
    echo "<h2>❌ Error:</h2>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}
?>
