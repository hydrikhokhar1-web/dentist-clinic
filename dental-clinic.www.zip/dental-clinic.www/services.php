<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';
$services = $pdo->query('SELECT * FROM services ORDER BY id')->fetchAll();
$pageTitle = 'Our care';
require __DIR__ . '/partials/header.php';
?>
<main>
    <section class="page-banner" style="--banner-image:url('https://images.unsplash.com/photo-1606265752439-1f18756aa2ec?auto=format&fit=crop&w=1600&q=85')"><div class="container"><span class="eyebrow">Our care</span><h1>Modern dentistry, considered from every angle.</h1><p>Prevention, restoration and aesthetic treatment brought together under one thoughtful clinical roof.</p></div></section>
    <section class="section"><div class="container"><div class="section-head reveal"><span class="eyebrow">Find your care</span><h2>Personal treatment for every kind of smile.</h2><p>Explore our core services, then book a conversation with the clinician best suited to your needs.</p></div><div class="service-grid">
        <?php foreach ($services as $service): ?>
            <article class="card service-card reveal"><div class="service-image"><img src="<?= e($service['image']) ?>" alt="<?= e($service['name']) ?>" loading="lazy"></div><div class="service-card-body"><h3><?= e($service['name']) ?></h3><p><?= e($service['description']) ?></p><p class="card-link">From <?= money($service['fee']) ?> · <?= e($service['duration']) ?></p><a class="button button-outline button-small" href="<?= app_url('service-details.php?id=' . (int) $service['id']) ?>">Learn more</a></div></article>
        <?php endforeach; ?>
    </div></div></section>
</main>
<?php require __DIR__ . '/partials/footer.php'; ?>
