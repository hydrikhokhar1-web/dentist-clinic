<?php
require_once __DIR__.'/config/database.php';

$email = 'admin@smilecare.com';
$password = 'admin123';

// Generate correct hash
$hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

// Update in database
$stmt = $pdo->prepare("UPDATE admins SET password_hash = ? WHERE email = ?");
$stmt->execute([$hash, $email]);

echo "✓ Admin password updated successfully!\n";
echo "Email: $email\n";
echo "Password: $password\n";
echo "Hash: $hash\n";

// Verify
$stmt = $pdo->prepare("SELECT password_hash FROM admins WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$record = $stmt->fetch();
echo "\n✓ Verified in database:\n";
echo "Hash in DB: " . $record['password_hash'] . "\n";

if (password_verify($password, $record['password_hash'])) {
    echo "✓ Password verification: SUCCESS\n";
} else {
    echo "✗ Password verification: FAILED\n";
}
?>
