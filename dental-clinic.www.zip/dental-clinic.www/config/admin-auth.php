<?php
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/functions.php';

function current_admin(PDO $pdo): ?array {
    if (empty($_SESSION['admin_id'])) return null;
    $stmt = $pdo->prepare("SELECT id, full_name, email FROM admins WHERE id=? LIMIT 1");
    $stmt->execute([$_SESSION['admin_id']]);
    return $stmt->fetch() ?: null;
}
?>