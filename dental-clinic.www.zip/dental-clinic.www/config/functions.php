<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('nura_dental_session');
    session_start();
}

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function app_url(string $path = ''): string
{
    $project = basename(dirname(__DIR__));
    return '/' . $project . '/' . ltrim($path, '/');
}

function redirect(string $path): never
{
    $location = preg_match('#^https?://#i', $path) ? $path : app_url($path);
    header('Location: ' . $location, true, 302);
    exit;
}

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

function flash(string $key, ?string $message = null): ?string
{
    if ($message !== null) {
        $_SESSION['_flash'][$key] = $message;
        return null;
    }
    $message = $_SESSION['_flash'][$key] ?? null;
    unset($_SESSION['_flash'][$key]);
    return $message;
}

function flash_set(string $type, string $message): void
{
    $_SESSION['_flash_message'] = ['type' => $type, 'message' => $message];
}

function flash_get(): ?array
{
    $message = $_SESSION['_flash_message'] ?? null;
    unset($_SESSION['_flash_message']);
    return is_array($message) ? $message : null;
}

function csrf_token(): string
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function verify_csrf(): void
{
    $token = $_POST['_csrf'] ?? '';
    if (!is_string($token) || !hash_equals($_SESSION['_csrf'] ?? '', $token)) {
        http_response_code(419);
        exit('Your form session has expired. Please go back and try again.');
    }
}

function setting(PDO $pdo, string $key, string $default = ''): string
{
    static $cache = [];
    if (!array_key_exists($key, $cache)) {
        $statement = $pdo->prepare('SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1');
        $statement->execute([$key]);
        $value = $statement->fetchColumn();
        $cache[$key] = $value === false ? $default : (string) $value;
    }
    return $cache[$key];
}

function money(float|string|int|null $amount): string
{
    return 'PKR ' . number_format((float) $amount, 0);
}

function require_patient(): void
{
    if (empty($_SESSION['user_id'])) {
        flash_set('warning', 'Please sign in to access your patient portal.');
        redirect('login.php');
    }
}

function require_admin(): void
{
    if (empty($_SESSION['admin_id'])) {
        flash_set('warning', 'Please sign in to access the admin area.');
        redirect('admin/login.php');
    }
}

function current_user(PDO $pdo): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    $statement = $pdo->prepare('SELECT id, full_name, email, phone, created_at FROM users WHERE id = ? LIMIT 1');
    $statement->execute([(int) $_SESSION['user_id']]);
    return $statement->fetch() ?: null;
}

function current_admin(PDO $pdo): ?array
{
    if (empty($_SESSION['admin_id'])) {
        return null;
    }
    $statement = $pdo->prepare('SELECT id, full_name, email FROM admins WHERE id = ? LIMIT 1');
    $statement->execute([(int) $_SESSION['admin_id']]);
    return $statement->fetch() ?: null;
}

function valid_date(string $date): bool
{
    $value = DateTime::createFromFormat('Y-m-d', $date);
    return $value !== false && $value->format('Y-m-d') === $date;
}

function appointment_slots(PDO $pdo, int $dentistId, string $date): array
{
    if ($dentistId < 1 || !valid_date($date)) {
        return [];
    }
    $day = (new DateTime($date))->format('l');
    $statement = $pdo->prepare('SELECT opening_time, closing_time, appointment_duration FROM doctor_schedules WHERE dentist_id = ? AND day_of_week = ? AND is_open = 1 LIMIT 1');
    $statement->execute([$dentistId, $day]);
    $schedule = $statement->fetch();
    if (!$schedule) {
        return [];
    }
    $slots = [];
    $cursor = new DateTime($date . ' ' . $schedule['opening_time']);
    $closing = new DateTime($date . ' ' . $schedule['closing_time']);
    $interval = max(15, (int) $schedule['appointment_duration']);
    while ($cursor < $closing) {
        $end = (clone $cursor)->modify('+' . $interval . ' minutes');
        if ($end > $closing) {
            break;
        }
        $slots[] = $cursor->format('H:i:s');
        $cursor = $end;
    }
    return $slots;
}

function status_class(string $status): string
{
    return strtolower(str_replace(' ', '-', $status));
}
