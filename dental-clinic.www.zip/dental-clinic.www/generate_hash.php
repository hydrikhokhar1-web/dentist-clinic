<?php
// Generate proper password hash for admin123
$password = 'admin123';
$hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
echo "Password: $password\n";
echo "Hash: $hash\n";

// Also verify it
if (password_verify('admin123', $hash)) {
    echo "✓ Password verification works\n";
}
?>
