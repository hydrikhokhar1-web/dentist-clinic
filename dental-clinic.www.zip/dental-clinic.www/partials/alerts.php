<?php if ($alert = flash_get()): ?>
    <div class="container alert-wrap">
        <div class="site-alert site-alert-<?= e($alert['type']) ?>" role="alert">
            <i class="fa-solid <?= $alert['type'] === 'success' ? 'fa-circle-check' : ($alert['type'] === 'warning' ? 'fa-circle-exclamation' : 'fa-circle-xmark') ?>"></i>
            <span><?= e($alert['message']) ?></span>
        </div>
    </div>
<?php endif; ?>
