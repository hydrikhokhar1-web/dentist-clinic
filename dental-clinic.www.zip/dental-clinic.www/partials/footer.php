<?php $footerServices = $pdo->query('SELECT id, name FROM services ORDER BY id LIMIT 4')->fetchAll(); ?>
<footer class="site-footer">
    <div class="container footer-layout">
        <div class="footer-intro"><a class="wordmark wordmark-light" href="<?= app_url() ?>"><span class="wordmark-symbol"><i class="fa-solid fa-tooth"></i></span><span>NURA<small>DENTAL STUDIO</small></span></a><p>Considered dental care for confident smiles, from your first consultation to lifelong preventative care.</p><div class="socials"><a href="<?= e(setting($pdo, 'facebook_url', '#')) ?>" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a><a href="<?= e(setting($pdo, 'instagram_url', '#')) ?>" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a><a href="<?= e(setting($pdo, 'whatsapp_url', '#')) ?>" aria-label="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a></div></div>
        <div class="footer-links"><h3>Explore</h3><a href="<?= app_url('about.php') ?>">Our studio</a><a href="<?= app_url('doctors.php') ?>">Meet clinicians</a><a href="<?= app_url('fees.php') ?>">Treatment fees</a><a href="<?= app_url('appointment.php') ?>">Book a visit</a></div>
        <div class="footer-links"><h3>Care</h3><?php foreach ($footerServices as $service): ?><a href="<?= app_url('service-details.php?id=' . (int) $service['id']) ?>"><?= e($service['name']) ?></a><?php endforeach; ?></div>
        <div class="footer-contact"><h3>Visit Nura</h3><p><?= e(setting($pdo, 'address', 'DHA Phase 5, Lahore, Pakistan')) ?></p><p><a href="tel:<?= e(setting($pdo, 'phone', '+923001234567')) ?>"><?= e(setting($pdo, 'phone', '+92 300 123 4567')) ?></a><br><a href="mailto:<?= e(setting($pdo, 'email', 'hello@nura.dental')) ?>"><?= e(setting($pdo, 'email', 'hello@nura.dental')) ?></a></p><p><?= e(setting($pdo, 'opening_hours', 'Mon–Sat · 10:00 AM – 8:00 PM')) ?></p></div>
    </div>
    <div class="container footer-map"><iframe title="Nura Dental Studio location map" loading="lazy" src="https://www.google.com/maps?q=Lahore%2C%20Pakistan&output=embed"></iframe></div>
    <div class="container footer-bottom"><span>© <?= date('Y') ?> Nura Dental Studio. All rights reserved.</span><button type="button" class="back-to-top" aria-label="Back to top"><i class="fa-solid fa-arrow-up"></i></button></div>
</footer>
<script src="<?= app_url('assets/js/script.js') ?>"></script>
</body>
</html>
