<?php
$currentPage = basename($_SERVER['PHP_SELF'] ?? '');
$isPatient = !empty($_SESSION['user_id']);
?>
<nav class="site-nav" id="siteNav">
    <div class="container nav-wrap">
        <a class="wordmark" href="<?= app_url() ?>" aria-label="Nura Dental Studio home">
            <span class="wordmark-symbol"><i class="fa-solid fa-tooth"></i></span>
            <span>NURA<small>DENTAL STUDIO</small></span>
        </a>
        <button class="nav-toggle" type="button" aria-label="Open navigation" aria-expanded="false" aria-controls="primaryNav"><span></span><span></span><span></span></button>
        <div class="nav-menu" id="primaryNav">
            <div class="nav-links">
                <?php foreach (['index.php' => 'Home', 'about.php' => 'Our studio', 'services.php' => 'Care', 'doctors.php' => 'Clinicians', 'fees.php' => 'Fees', 'contact.php' => 'Contact'] as $file => $label): ?>
                    <a class="<?= $currentPage === $file ? 'is-active' : '' ?>" href="<?= app_url($file) ?>"><?= $label ?></a>
                <?php endforeach; ?>
            </div>
            <div class="nav-actions">
                <?php if ($isPatient): ?>
                    <a class="text-action" href="<?= app_url('patient/dashboard.php') ?>"><i class="fa-regular fa-user"></i> My portal</a>
                <?php else: ?>
                    <a class="text-action" href="<?= app_url('login.php') ?>">Patient sign in</a>
                <?php endif; ?>
                <a class="button button-primary button-small" href="<?= app_url('appointment.php') ?>">Book a visit <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
            </div>
        </div>
    </div>
</nav>
