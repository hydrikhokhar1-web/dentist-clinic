<?php
if (!isset($pdo)) {
    require_once __DIR__ . '/../config/database.php';
    require_once __DIR__ . '/../config/functions.php';
}
$clinicName = setting($pdo, 'clinic_name', 'Nura Dental Studio');
$pageTitle = $pageTitle ?? $clinicName;
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Nura Dental Studio — thoughtful, modern dental care in Pakistan.">
    <title><?= e($pageTitle) ?> | <?= e($clinicName) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="<?= app_url('assets/css/style.css') ?>">
</head>
<body>
    <div class="contact-strip"><div class="container strip-inner"><span><i class="fa-regular fa-clock"></i> <?= e(setting($pdo, 'opening_hours', 'Mon–Sat · 10:00 AM – 8:00 PM')) ?></span><span><a href="tel:<?= e(setting($pdo, 'phone', '+923001234567')) ?>"><i class="fa-solid fa-phone"></i> <?= e(setting($pdo, 'phone', '+92 300 123 4567')) ?></a><a href="mailto:<?= e(setting($pdo, 'email', 'hello@nura.dental')) ?>"><i class="fa-regular fa-envelope"></i> <?= e(setting($pdo, 'email', 'hello@nura.dental')) ?></a></span></div></div>
    <?php require __DIR__ . '/navbar.php'; ?>
    <?php require __DIR__ . '/alerts.php'; ?>
