Image replacement guide
=======================
The demo uses remote Unsplash image URLs so the project works immediately after import.

To use local images instead:
1. Place optimised JPG or WebP images in this folder.
2. In Admin > Clinicians or Admin > Services, replace the image URL with a path such as:
   assets/images/dr-raffay.webp
3. Keep portrait images near a 4:5 ratio and service images near a 3:2 ratio for the best layout.
