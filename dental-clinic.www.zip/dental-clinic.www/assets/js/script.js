document.addEventListener('DOMContentLoaded', () => {
    const nav = document.querySelector('.site-nav');
    const toggle = document.querySelector('.nav-toggle');
    const menu = document.querySelector('.nav-menu');

    if (toggle && menu) {
        toggle.addEventListener('click', () => {
            const open = menu.classList.toggle('open');
            toggle.setAttribute('aria-expanded', String(open));
            document.body.classList.toggle('menu-open', open);
        });
        menu.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
            menu.classList.remove('open');
            document.body.classList.remove('menu-open');
            toggle.setAttribute('aria-expanded', 'false');
        }));
    }

    window.addEventListener('scroll', () => nav?.classList.toggle('is-scrolled', window.scrollY > 10), { passive: true });

    const reveals = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
            if (entry.isIntersecting) { entry.target.classList.add('in-view'); observer.unobserve(entry.target); }
        }), { threshold: .12 });
        reveals.forEach((node) => observer.observe(node));
    } else { reveals.forEach((node) => node.classList.add('in-view')); }

    document.querySelectorAll('[data-count]').forEach((node) => {
        const target = Number(node.dataset.count || 0);
        const suffix = node.dataset.suffix || '';
        const paint = () => {
            const started = performance.now();
            const frame = (now) => { const value = Math.min(target, Math.round(target * Math.min(1, (now - started) / 900))); node.textContent = value + suffix; if (value < target) requestAnimationFrame(frame); };
            requestAnimationFrame(frame);
        };
        if ('IntersectionObserver' in window) new IntersectionObserver((entries, observer) => { if (entries[0].isIntersecting) { paint(); observer.disconnect(); } }, { threshold: .7 }).observe(node); else paint();
    });

    document.querySelectorAll('video[data-fallback]').forEach((video) => video.addEventListener('error', () => video.closest('.intro-panel')?.classList.add('video-missing')));
    document.querySelector('.back-to-top')?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

    const appointmentForm = document.querySelector('[data-appointment-form]');
    const doctorField = document.querySelector('#dentist_id');
    const dateField = document.querySelector('#appointment_date');
    const timeField = document.querySelector('#appointment_time');
    const slotNote = document.querySelector('#slot-note');
    const loadSlots = async () => {
        if (!doctorField?.value || !dateField?.value || !timeField) return;
        timeField.innerHTML = '<option value="">Loading available times…</option>';
        timeField.disabled = true;
        try {
            const response = await fetch(`appointment-slots.php?dentist_id=${encodeURIComponent(doctorField.value)}&date=${encodeURIComponent(dateField.value)}`);
            const data = await response.json();
            timeField.innerHTML = '<option value="">Select an available time</option>';
            (data.slots || []).forEach((slot) => {
                const option = document.createElement('option'); option.value = slot.value; option.textContent = slot.label; timeField.appendChild(option);
            });
            timeField.disabled = !(data.slots || []).length;
            if (slotNote) slotNote.textContent = data.message || ((data.slots || []).length ? 'Choose a time that works for you.' : 'No times are available for this day.');
        } catch (_) {
            timeField.innerHTML = '<option value="">Unable to load times</option>';
            if (slotNote) slotNote.textContent = 'Please choose another date or contact us for help.';
        }
    };
    if (appointmentForm) {
        doctorField?.addEventListener('change', loadSlots);
        dateField?.addEventListener('change', loadSlots);
        if (doctorField?.value && dateField?.value) loadSlots();
    }
});
