Optional intro video
====================
Place a short, muted MP4 named clinic-intro.mp4 in this folder to replace the animated video-style fallback on the homepage.
Recommended: 3–4 seconds, 1920×1080 or 1080×1080, H.264 MP4, under 8 MB.
