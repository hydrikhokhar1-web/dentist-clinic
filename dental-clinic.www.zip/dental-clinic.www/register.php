<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';
if (!empty($_SESSION['user_id'])) { redirect('patient/dashboard.php'); }
$values = ['full_name' => '', 'email' => '', 'phone' => ''];
if (is_post()) {
    verify_csrf();
    foreach ($values as $key => $value) { $values[$key] = trim((string) ($_POST[$key] ?? '')); }
    $password = (string) ($_POST['password'] ?? '');
    $confirmPassword = (string) ($_POST['confirm_password'] ?? '');
    $errors = [];
    if (mb_strlen($values['full_name']) < 2 || mb_strlen($values['full_name']) > 120) { $errors[] = 'Please enter your full name.'; }
    if (!filter_var($values['email'], FILTER_VALIDATE_EMAIL)) { $errors[] = 'Please enter a valid email address.'; }
    if (mb_strlen($values['phone']) < 7 || mb_strlen($values['phone']) > 40) { $errors[] = 'Please enter a valid phone number.'; }
    if (strlen($password) < 8) { $errors[] = 'Your password must be at least 8 characters.'; }
    if ($password !== $confirmPassword) { $errors[] = 'Your password confirmation does not match.'; }
    if (!$errors) {
        $exists = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $exists->execute([$values['email']]);
        if ($exists->fetch()) { $errors[] = 'An account already exists for that email address.'; }
    }
    if (!$errors) {
        $statement = $pdo->prepare('INSERT INTO users (full_name, email, phone, password_hash) VALUES (?, ?, ?, ?)');
        $statement->execute([$values['full_name'], $values['email'], $values['phone'], password_hash($password, PASSWORD_DEFAULT)]);
        flash_set('success', 'Your account is ready. You can now sign in.');
        redirect('login.php');
    }
    flash_set('error', implode(' ', $errors));
}
$alert = flash_get();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Create account | Nura Dental Studio</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"><link rel="stylesheet" href="assets/css/style.css"></head><body><main class="auth-page"><aside class="auth-aside"><a class="wordmark wordmark-light" href="<?= app_url() ?>"><span class="wordmark-symbol"><i class="fa-solid fa-tooth"></i></span><span>NURA<small>DENTAL STUDIO</small></span></a><div><span class="eyebrow" style="color:#d7b97d">Patient portal</span><h1>Care that stays connected.</h1><p>Register once to keep your details and appointment history in one secure place.</p></div><small>Thoughtful dentistry, from first visit onwards.</small></aside><section class="auth-main"><div class="auth-box"><a class="wordmark" href="<?= app_url() ?>"><span class="wordmark-symbol"><i class="fa-solid fa-tooth"></i></span><span>NURA<small>DENTAL STUDIO</small></span></a><h1>Create your account.</h1><p>It takes just a moment.</p><?php if ($alert): ?><div class="site-alert site-alert-<?= e($alert['type']) ?>"><i class="fa-solid fa-circle-exclamation"></i><?= e($alert['message']) ?></div><?php endif; ?><form method="post"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><div class="form-group"><label for="full_name">Full name</label><input class="form-control" id="full_name" name="full_name" value="<?= e($values['full_name']) ?>" autocomplete="name" required></div><div class="form-group"><label for="email">Email address</label><input class="form-control" id="email" type="email" name="email" value="<?= e($values['email']) ?>" autocomplete="email" required></div><div class="form-group"><label for="phone">Phone number</label><input class="form-control" id="phone" name="phone" value="<?= e($values['phone']) ?>" autocomplete="tel" required></div><div class="form-group"><label for="password">Password</label><input class="form-control" id="password" type="password" name="password" minlength="8" autocomplete="new-password" required></div><div class="form-group"><label for="confirm_password">Confirm password</label><input class="form-control" id="confirm_password" type="password" name="confirm_password" minlength="8" autocomplete="new-password" required></div><button class="button button-primary" type="submit">Create account <i class="fa-solid fa-arrow-right"></i></button></form><p class="auth-foot">Already have an account? <a href="<?= app_url('login.php') ?>">Sign in</a></p></div></section></main></body></html>
