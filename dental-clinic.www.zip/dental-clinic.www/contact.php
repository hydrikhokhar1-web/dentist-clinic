<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';
$values = ['name' => '', 'email' => '', 'phone' => '', 'subject' => '', 'message' => ''];
if (is_post()) {
    verify_csrf();
    foreach ($values as $key => $value) { $values[$key] = trim((string) ($_POST[$key] ?? '')); }
    if (mb_strlen($values['name']) < 2 || !filter_var($values['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($values['message']) < 5) {
        flash_set('error', 'Please enter your name, a valid email address and a short message.');
    } else {
        $statement = $pdo->prepare('INSERT INTO contact_messages (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)');
        $statement->execute([$values['name'], $values['email'], $values['phone'] ?: null, $values['subject'] ?: null, $values['message']]);
        flash_set('success', 'Thank you. Your message has been sent and our team will be in touch soon.');
        redirect('contact.php');
    }
}
$pageTitle = 'Contact us';
require __DIR__ . '/partials/header.php';
?>
<main>
    <section class="page-banner" style="--banner-image:url('https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=1600&q=85')"><div class="container"><span class="eyebrow">Contact Nura</span><h1>We’re here when you need us.</h1><p>Call, email or send a message. Our team will be glad to help you plan your visit.</p></div></section>
    <section class="section"><div class="container form-shell"><div class="reveal"><span class="eyebrow">Find the studio</span><h2>Let’s start a conversation.</h2><div class="contact-list"><div class="contact-item"><i class="fa-solid fa-location-dot"></i><span><strong>Visit us</strong><?= e(setting($pdo, 'address', 'DHA Phase 5, Lahore, Pakistan')) ?></span></div><div class="contact-item"><i class="fa-solid fa-phone"></i><span><strong>Call us</strong><a href="tel:<?= e(setting($pdo, 'phone', '+923001234567')) ?>"><?= e(setting($pdo, 'phone', '+92 300 123 4567')) ?></a></span></div><div class="contact-item"><i class="fa-regular fa-envelope"></i><span><strong>Email us</strong><a href="mailto:<?= e(setting($pdo, 'email', 'hello@nura.dental')) ?>"><?= e(setting($pdo, 'email', 'hello@nura.dental')) ?></a></span></div><div class="contact-item"><i class="fa-regular fa-clock"></i><span><strong>Studio hours</strong><?= e(setting($pdo, 'opening_hours', 'Mon–Sat · 10:00 AM – 8:00 PM')) ?></span></div><div class="contact-item"><i class="fa-solid fa-kit-medical"></i><span><strong>Urgent care</strong><?= e(setting($pdo, 'emergency_number', '+92 300 123 4567')) ?></span></div></div></div>
        <div class="card form-card reveal"><h2>Send a message</h2><p>We typically reply during studio hours.</p><form method="post"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><div class="form-grid"><div class="form-group"><label for="name">Name *</label><input class="form-control" id="name" name="name" value="<?= e($values['name']) ?>" required></div><div class="form-group"><label for="email">Email *</label><input class="form-control" id="email" type="email" name="email" value="<?= e($values['email']) ?>" required></div><div class="form-group"><label for="phone">Phone</label><input class="form-control" id="phone" name="phone" value="<?= e($values['phone']) ?>"></div><div class="form-group"><label for="subject">Subject</label><input class="form-control" id="subject" name="subject" value="<?= e($values['subject']) ?>"></div><div class="form-group full"><label for="message">How can we help? *</label><textarea class="form-control" id="message" name="message" required><?= e($values['message']) ?></textarea></div></div><button class="button button-primary" type="submit">Send message <i class="fa-solid fa-arrow-right"></i></button></form></div>
    </div></section>
</main>
<?php require __DIR__ . '/partials/footer.php'; ?>
