SMILECARE DENTAL CLINIC - PHP + MYSQL + XAMPP
================================================

1. Install XAMPP.
2. Copy the dental-clinic folder to:
   C:\xampp\htdocs\dental-clinic\
3. Start Apache and MySQL in XAMPP.
4. Open phpMyAdmin:
   http://localhost/phpmyadmin/
5. Import:
   database/database.sql
6. Open:
   http://localhost/dental-clinic/

ADMIN LOGIN
-----------
URL: http://localhost/dental-clinic/admin/login.php
Email: admin@smilecare.com
Password: Admin@12345

PATIENT
-------
Register from:
http://localhost/dental-clinic/register.php

Notes:
- Database uses PDO and prepared statements.
- Passwords are stored with password_hash().
- Appointment booking checks existing dentist/date/time bookings.
- Fees, services, dentists, appointments, schedules and messages are managed from admin.
- The supplied clinic mockup is included at assets/images/clinic-mockup.png and used as a visual image source.
