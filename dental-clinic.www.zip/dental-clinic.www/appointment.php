<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';

$dentists = $pdo->query('SELECT id, name, specialization FROM dentists ORDER BY name')->fetchAll();
$services = $pdo->query('SELECT id, name FROM services ORDER BY name')->fetchAll();
$user = current_user($pdo);
$values = [
    'patient_name' => $user['full_name'] ?? '', 'email' => $user['email'] ?? '', 'phone' => $user['phone'] ?? '',
    'dentist_id' => filter_input(INPUT_GET, 'dentist', FILTER_VALIDATE_INT) ?: '',
    'service_id' => filter_input(INPUT_GET, 'service', FILTER_VALIDATE_INT) ?: '',
    'appointment_date' => '', 'appointment_time' => '', 'message' => '',
];

if (is_post()) {
    verify_csrf();
    foreach ($values as $key => $value) { $values[$key] = trim((string) ($_POST[$key] ?? $value)); }
    $dentistId = (int) $values['dentist_id'];
    $serviceId = (int) $values['service_id'];
    $date = $values['appointment_date'];
    $time = $values['appointment_time'];
    $errors = [];

    if (mb_strlen($values['patient_name']) < 2 || mb_strlen($values['patient_name']) > 120) { $errors[] = 'Please enter your full name.'; }
    if (!filter_var($values['email'], FILTER_VALIDATE_EMAIL)) { $errors[] = 'Please enter a valid email address.'; }
    if (mb_strlen($values['phone']) < 7 || mb_strlen($values['phone']) > 40) { $errors[] = 'Please enter a valid phone number.'; }
    if (!valid_date($date) || $date < date('Y-m-d')) { $errors[] = 'Please choose a future appointment date.'; }

    $exists = $pdo->prepare('SELECT (SELECT COUNT(*) FROM dentists WHERE id = ?) AS dentist_found, (SELECT COUNT(*) FROM services WHERE id = ?) AS service_found');
    $exists->execute([$dentistId, $serviceId]);
    $selection = $exists->fetch();
    if (empty($selection['dentist_found']) || empty($selection['service_found'])) { $errors[] = 'Please select a valid clinician and treatment.'; }
    if (!$errors && !in_array($time, appointment_slots($pdo, $dentistId, $date), true)) { $errors[] = 'Please select a valid available appointment time.'; }

    if (!$errors) {
        try {
            $insert = $pdo->prepare('INSERT INTO appointments (user_id, patient_name, email, phone, dentist_id, service_id, appointment_date, appointment_time, message) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $insert->execute([$user['id'] ?? null, $values['patient_name'], $values['email'], $values['phone'], $dentistId, $serviceId, $date, $time, $values['message'] ?: null]);
            flash_set('success', 'Your appointment request is in. We will confirm it shortly.');
            redirect('appointment.php');
        } catch (PDOException $exception) {
            if ($exception->getCode() === '23000') { $errors[] = 'That appointment time was just taken. Please choose another available time.'; } else { throw $exception; }
        }
    }
    if ($errors) { flash_set('error', implode(' ', $errors)); }
}

$pageTitle = 'Book an appointment';
require __DIR__ . '/partials/header.php';
?>
<main>
    <section class="page-banner" style="--banner-image:url('https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1600&q=85')"><div class="container"><span class="eyebrow">Book a visit</span><h1>Let’s find time for your smile.</h1><p>Choose a clinician, care option and time that suits you. We’ll handle the rest.</p></div></section>
    <section class="section"><div class="container form-shell"><aside class="form-side reveal"><span class="eyebrow" style="color:#d7b97d">Your Nura visit</span><h2>A little easier, from the start.</h2><p>Submit your preferred appointment and our team will review and confirm it with you.</p><ul><li><i class="fa-solid fa-check"></i><span>Choose from live clinician availability</span></li><li><i class="fa-solid fa-check"></i><span>Clear confirmation and reminders</span></li><li><i class="fa-solid fa-check"></i><span>Need help? Call <?= e(setting($pdo, 'phone', '+92 300 123 4567')) ?></span></li></ul></aside>
        <div class="card form-card reveal"><h2>Appointment details</h2><p>Fields marked with * are required.</p><form method="post" data-appointment-form novalidate><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><div class="form-grid"><div class="form-group"><label for="patient_name">Patient name *</label><input class="form-control" id="patient_name" name="patient_name" value="<?= e($values['patient_name']) ?>" required></div><div class="form-group"><label for="email">Email *</label><input class="form-control" id="email" type="email" name="email" value="<?= e($values['email']) ?>" required></div><div class="form-group"><label for="phone">Phone *</label><input class="form-control" id="phone" name="phone" value="<?= e($values['phone']) ?>" required></div><div class="form-group"><label for="dentist_id">Clinician *</label><select class="form-control" id="dentist_id" name="dentist_id" required><option value="">Select a clinician</option><?php foreach ($dentists as $dentist): ?><option value="<?= (int) $dentist['id'] ?>" <?= (string) $values['dentist_id'] === (string) $dentist['id'] ? 'selected' : '' ?>><?= e($dentist['name']) ?> — <?= e($dentist['specialization']) ?></option><?php endforeach; ?></select></div><div class="form-group"><label for="service_id">Treatment *</label><select class="form-control" id="service_id" name="service_id" required><option value="">Select a treatment</option><?php foreach ($services as $service): ?><option value="<?= (int) $service['id'] ?>" <?= (string) $values['service_id'] === (string) $service['id'] ? 'selected' : '' ?>><?= e($service['name']) ?></option><?php endforeach; ?></select></div><div class="form-group"><label for="appointment_date">Preferred date *</label><input class="form-control" id="appointment_date" type="date" name="appointment_date" min="<?= date('Y-m-d') ?>" value="<?= e($values['appointment_date']) ?>" required></div><div class="form-group"><label for="appointment_time">Available time *</label><select class="form-control" id="appointment_time" name="appointment_time" disabled required><option value="">Select a clinician and date</option></select><span class="form-help" id="slot-note">Available times appear after you choose a clinician and date.</span></div><div class="form-group full"><label for="message">Anything we should know?</label><textarea class="form-control" id="message" name="message" placeholder="Tell us about your concerns or preferences."><?= e($values['message']) ?></textarea></div></div><button class="button button-primary" type="submit">Request appointment <i class="fa-solid fa-arrow-right"></i></button></form></div>
    </div></section>
</main>
<?php require __DIR__ . '/partials/footer.php'; ?>
