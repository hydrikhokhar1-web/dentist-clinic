<?php
declare(strict_types=1);
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';

header('Content-Type: application/json; charset=utf-8');
$dentistId = filter_input(INPUT_GET, 'dentist_id', FILTER_VALIDATE_INT) ?: 0;
$date = trim((string) ($_GET['date'] ?? ''));

if (!$dentistId || !valid_date($date) || $date < date('Y-m-d')) {
    echo json_encode(['slots' => [], 'message' => 'Choose a future date and clinician first.']);
    exit;
}

$available = appointment_slots($pdo, $dentistId, $date);
$bookedStatement = $pdo->prepare('SELECT appointment_time FROM appointments WHERE dentist_id = ? AND appointment_date = ?');
$bookedStatement->execute([$dentistId, $date]);
$booked = array_flip(array_map(static fn(array $row): string => $row['appointment_time'], $bookedStatement->fetchAll()));

$slots = [];
foreach ($available as $slot) {
    if (!isset($booked[$slot])) {
        $slots[] = ['value' => $slot, 'label' => date('g:i A', strtotime($slot))];
    }
}

echo json_encode(['slots' => $slots, 'message' => $slots ? 'Choose a time that works for you.' : 'No appointment times are available for this day.']);
