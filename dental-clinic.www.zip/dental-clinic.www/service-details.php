<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';
$serviceId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$statement = $pdo->prepare('SELECT * FROM services WHERE id = ? LIMIT 1');
$statement->execute([$serviceId]);
$service = $statement->fetch();
if (!$service) { redirect('services.php'); }
$pageTitle = $service['name'];
require __DIR__ . '/partials/header.php';
?>
<main>
    <section class="page-banner" style="--banner-image:url('<?= e($service['image']) ?>')"><div class="container"><span class="eyebrow">Nura care</span><h1><?= e($service['name']) ?></h1><p><?= e($service['description']) ?></p></div></section>
    <section class="section"><div class="container detail-grid"><img class="detail-image reveal" src="<?= e($service['image']) ?>" alt="<?= e($service['name']) ?>"><div class="reveal"><span class="eyebrow">Your treatment</span><h2>Care tailored around you.</h2><p class="muted"><?= e($service['details']) ?></p><div class="detail-meta"><div><span>Starting from</span><strong><?= money($service['fee']) ?></strong></div><div><span>Typical visit</span><strong><?= e($service['duration']) ?></strong></div></div><a class="button button-primary" href="<?= app_url('appointment.php?service=' . (int) $service['id']) ?>">Book this treatment <i class="fa-solid fa-arrow-right"></i></a></div></div></section>
</main>
<?php require __DIR__ . '/partials/footer.php'; ?>
