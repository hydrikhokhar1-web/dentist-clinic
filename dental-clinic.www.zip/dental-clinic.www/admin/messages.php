<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
require_admin();
if (is_post()) {
    verify_csrf();
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT) ?: 0;
    $action = (string) ($_POST['action'] ?? '');
    if ($id && $action === 'delete') { $statement = $pdo->prepare('DELETE FROM contact_messages WHERE id = ?'); $statement->execute([$id]); flash_set('success', 'Message deleted.'); }
    elseif ($id && in_array($action, ['New', 'Read', 'Archived'], true)) { $statement = $pdo->prepare('UPDATE contact_messages SET status = ? WHERE id = ?'); $statement->execute([$action, $id]); flash_set('success', 'Message status updated.'); }
    redirect('admin/messages.php');
}
$messages = $pdo->query('SELECT * FROM contact_messages ORDER BY created_at DESC')->fetchAll();
$adminTitle = 'Messages';
require __DIR__ . '/_header.php';
?>
<div class="admin-page-heading"><div><span class="admin-kicker">Inbox</span><h1>Messages.</h1><p class="muted">Questions received through the public contact form.</p></div></div><section class="admin-card table-card" style="padding:0"><div class="table-wrap"><table class="data-table"><thead><tr><th>Sender</th><th>Message</th><th>Received</th><th>Status</th><th>Actions</th></tr></thead><tbody><?php foreach ($messages as $message): ?><tr><td><strong><?= e($message['name']) ?></strong><br><small><?= e($message['email']) ?><br><?= e($message['phone'] ?? '') ?></small></td><td><strong><?= e($message['subject'] ?: 'No subject') ?></strong><br><small><?= nl2br(e($message['message'])) ?></small></td><td><?= e(date('d M Y', strtotime($message['created_at']))) ?></td><td><span class="status <?= $message['status'] === 'New' ? 'pending' : ($message['status'] === 'Read' ? 'confirmed' : 'completed') ?>"><?= e($message['status']) ?></span></td><td><div class="admin-table-actions"><form method="post"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><input type="hidden" name="id" value="<?= (int) $message['id'] ?>"><input type="hidden" name="action" value="<?= $message['status'] === 'New' ? 'Read' : 'Archived' ?>"><button class="button button-outline" type="submit"><?= $message['status'] === 'New' ? 'Mark read' : 'Archive' ?></button></form><form method="post" onsubmit="return confirm('Delete this message?');"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><input type="hidden" name="id" value="<?= (int) $message['id'] ?>"><input type="hidden" name="action" value="delete"><button class="button button-danger" type="submit">Delete</button></form></div></td></tr><?php endforeach; ?></tbody></table></div><?php if (!$messages): ?><div class="empty-state"><i class="fa-regular fa-envelope"></i><p>Your inbox is clear.</p></div><?php endif; ?></section>
<?php require __DIR__ . '/_footer.php'; ?>
