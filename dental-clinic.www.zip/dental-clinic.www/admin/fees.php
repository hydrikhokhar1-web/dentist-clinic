<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
require_admin();
if (is_post()) {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT) ?: 0;
    if ($action === 'delete' && $id) { $delete = $pdo->prepare('DELETE FROM fees WHERE id = ?'); $delete->execute([$id]); flash_set('success', 'Fee item removed.'); redirect('admin/fees.php'); }
    $category = trim((string) ($_POST['category'] ?? ''));
    $name = trim((string) ($_POST['name'] ?? ''));
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    $duration = trim((string) ($_POST['duration'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));
    if (!$category || !$name || $price === false || $price < 0) { flash_set('error', 'Please enter a category, treatment name and valid price.'); }
    elseif ($action === 'edit' && $id) { $update = $pdo->prepare('UPDATE fees SET category = ?, name = ?, price = ?, duration = ?, description = ? WHERE id = ?'); $update->execute([$category, $name, $price, $duration ?: null, $description ?: null, $id]); flash_set('success', 'Fee item updated.'); }
    else { $insert = $pdo->prepare('INSERT INTO fees (category, name, price, duration, description) VALUES (?, ?, ?, ?, ?)'); $insert->execute([$category, $name, $price, $duration ?: null, $description ?: null]); flash_set('success', 'Fee item added.'); }
    redirect('admin/fees.php');
}
$editId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$editing = null;
if ($editId) { $find = $pdo->prepare('SELECT * FROM fees WHERE id = ?'); $find->execute([$editId]); $editing = $find->fetch() ?: null; }
$fees = $pdo->query('SELECT * FROM fees ORDER BY category, name')->fetchAll();
$adminTitle = 'Fees';
require __DIR__ . '/_header.php';
?>
<div class="admin-page-heading"><div><span class="admin-kicker">Pricing list</span><h1>Treatment fees.</h1><p class="muted">Add, amend or remove fee entries shown on the public fees page.</p></div></div><section class="admin-card"><h2><?= $editing ? 'Edit fee item' : 'Add fee item' ?></h2><form method="post"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><input type="hidden" name="action" value="<?= $editing ? 'edit' : 'create' ?>"><?php if ($editing): ?><input type="hidden" name="id" value="<?= (int) $editing['id'] ?>"><?php endif; ?><div class="form-grid"><div class="form-group"><label>Category *</label><input class="form-control" name="category" value="<?= e($editing['category'] ?? '') ?>" required></div><div class="form-group"><label>Treatment name *</label><input class="form-control" name="name" value="<?= e($editing['name'] ?? '') ?>" required></div><div class="form-group"><label>Price *</label><input class="form-control" type="number" min="0" name="price" value="<?= e((string) ($editing['price'] ?? '')) ?>" required></div><div class="form-group"><label>Duration</label><input class="form-control" name="duration" value="<?= e($editing['duration'] ?? '') ?>"></div><div class="form-group full"><label>Description</label><textarea class="form-control" name="description"><?= e($editing['description'] ?? '') ?></textarea></div></div><button class="button button-primary" type="submit"><?= $editing ? 'Save fee item' : 'Add fee item' ?></button><?php if ($editing): ?><a class="button button-outline" href="<?= app_url('admin/fees.php') ?>">Cancel</a><?php endif; ?></form></section><section class="admin-card table-card" style="padding:0;margin-top:20px"><div class="table-wrap"><table class="data-table"><thead><tr><th>Category</th><th>Treatment</th><th>Price</th><th>Duration</th><th></th></tr></thead><tbody><?php foreach ($fees as $fee): ?><tr><td><?= e($fee['category']) ?></td><td><?= e($fee['name']) ?></td><td><?= money($fee['price']) ?></td><td><?= e($fee['duration'] ?? '—') ?></td><td><div class="admin-table-actions"><a class="button button-outline" href="<?= app_url('admin/fees.php?id=' . (int) $fee['id']) ?>">Edit</a><form method="post" onsubmit="return confirm('Remove this fee item?');"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $fee['id'] ?>"><button class="button button-danger" type="submit">Delete</button></form></div></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php require __DIR__ . '/_footer.php'; ?>
