<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
require_admin();
if (is_post()) {
    verify_csrf();
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT) ?: 0;
    $data = []; foreach (['name', 'description', 'details', 'duration', 'image'] as $field) { $data[$field] = trim((string) ($_POST[$field] ?? '')); }
    $fee = filter_input(INPUT_POST, 'fee', FILTER_VALIDATE_FLOAT);
    if (!$id || !$data['name'] || !$data['description'] || !$data['details'] || !$data['duration'] || !$data['image'] || $fee === false || $fee < 0) { flash_set('error', 'Please complete every service field with a valid starting fee.'); }
    else { $update = $pdo->prepare('UPDATE services SET name = ?, description = ?, details = ?, fee = ?, duration = ?, image = ? WHERE id = ?'); $update->execute([$data['name'], $data['description'], $data['details'], $fee, $data['duration'], $data['image'], $id]); flash_set('success', 'Service updated.'); }
    redirect('admin/services.php?id=' . $id);
}
$serviceId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$services = $pdo->query('SELECT * FROM services ORDER BY id')->fetchAll();
$editing = null; foreach ($services as $service) { if ((int) $service['id'] === $serviceId) { $editing = $service; break; } }
$adminTitle = 'Services';
require __DIR__ . '/_header.php';
?>
<div class="admin-page-heading"><div><span class="admin-kicker">Treatment catalogue</span><h1>Services.</h1><p class="muted">Update the eight core treatments presented on the public website.</p></div></div><section class="admin-card table-card" style="padding:0"><div class="table-wrap"><table class="data-table"><thead><tr><th>Service</th><th>Starting fee</th><th>Duration</th><th></th></tr></thead><tbody><?php foreach ($services as $service): ?><tr><td><?= e($service['name']) ?></td><td><?= money($service['fee']) ?></td><td><?= e($service['duration']) ?></td><td><a class="button button-outline" href="<?= app_url('admin/services.php?id=' . (int) $service['id']) ?>">Edit service</a></td></tr><?php endforeach; ?></tbody></table></div></section><?php if ($editing): ?><section class="admin-card" style="margin-top:20px"><h2>Edit <?= e($editing['name']) ?></h2><form method="post"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><input type="hidden" name="id" value="<?= (int) $editing['id'] ?>"><div class="form-grid"><div class="form-group"><label>Name *</label><input class="form-control" name="name" value="<?= e($editing['name']) ?>" required></div><div class="form-group"><label>Starting fee *</label><input class="form-control" type="number" min="0" name="fee" value="<?= e((string) $editing['fee']) ?>" required></div><div class="form-group"><label>Duration *</label><input class="form-control" name="duration" value="<?= e($editing['duration']) ?>" required></div><div class="form-group"><label>Image URL *</label><input class="form-control" name="image" value="<?= e($editing['image']) ?>" required></div><div class="form-group full"><label>Short description *</label><textarea class="form-control" name="description" required><?= e($editing['description']) ?></textarea></div><div class="form-group full"><label>Treatment details *</label><textarea class="form-control" name="details" required><?= e($editing['details']) ?></textarea></div></div><button class="button button-primary" type="submit">Save service</button></form></section><?php endif; ?>
<?php require __DIR__ . '/_footer.php'; ?>
