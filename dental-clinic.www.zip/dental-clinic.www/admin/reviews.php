<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
require_admin();
if (is_post()) {
    verify_csrf();
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT) ?: 0;
    $action = (string) ($_POST['action'] ?? '');
    if ($id && $action === 'delete') { $delete = $pdo->prepare('DELETE FROM reviews WHERE id = ?'); $delete->execute([$id]); flash_set('success', 'Review deleted.'); }
    elseif ($id && in_array($action, ['Pending', 'Approved', 'Rejected'], true)) { $update = $pdo->prepare('UPDATE reviews SET status = ? WHERE id = ?'); $update->execute([$action, $id]); flash_set('success', 'Review status updated.'); }
    redirect('admin/reviews.php');
}
$reviews = $pdo->query("SELECT r.*, COALESCE(u.full_name, 'Guest patient') AS patient_name FROM reviews r LEFT JOIN users u ON u.id = r.user_id ORDER BY r.created_at DESC")->fetchAll();
$adminTitle = 'Reviews';
require __DIR__ . '/_header.php';
?>
<div class="admin-page-heading"><div><span class="admin-kicker">Patient feedback</span><h1>Reviews.</h1><p class="muted">Approve helpful patient feedback for use across your clinic communications.</p></div></div><section class="admin-card table-card" style="padding:0"><div class="table-wrap"><table class="data-table"><thead><tr><th>Patient</th><th>Rating</th><th>Feedback</th><th>Status</th><th>Actions</th></tr></thead><tbody><?php foreach ($reviews as $review): ?><tr><td><?= e($review['patient_name']) ?><br><small><?= e(date('d M Y', strtotime($review['created_at']))) ?></small></td><td><?= str_repeat('★', (int) $review['rating']) ?></td><td><?= e($review['review']) ?></td><td><span class="status <?= $review['status'] === 'Approved' ? 'confirmed' : ($review['status'] === 'Rejected' ? 'rejected' : 'pending') ?>"><?= e($review['status']) ?></span></td><td><div class="admin-table-actions"><form method="post"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><input type="hidden" name="id" value="<?= (int) $review['id'] ?>"><select class="form-control" name="action" aria-label="Review status"><?php foreach (['Pending', 'Approved', 'Rejected'] as $status): ?><option <?= $review['status'] === $status ? 'selected' : '' ?>><?= e($status) ?></option><?php endforeach; ?></select><button class="button button-primary" type="submit">Save</button></form><form method="post" onsubmit="return confirm('Delete this review?');"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><input type="hidden" name="id" value="<?= (int) $review['id'] ?>"><input type="hidden" name="action" value="delete"><button class="button button-danger" type="submit">Delete</button></form></div></td></tr><?php endforeach; ?></tbody></table></div><?php if (!$reviews): ?><div class="empty-state"><i class="fa-regular fa-star"></i><p>No reviews have been submitted yet.</p></div><?php endif; ?></section>
<?php require __DIR__ . '/_footer.php'; ?>
