<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
require_admin();
if (is_post()) {
    verify_csrf();
    $dentistId = filter_input(INPUT_POST, 'dentist_id', FILTER_VALIDATE_INT) ?: 0;
    $day = (string) ($_POST['day_of_week'] ?? '');
    $open = (string) ($_POST['opening_time'] ?? '');
    $close = (string) ($_POST['closing_time'] ?? '');
    $duration = filter_input(INPUT_POST, 'appointment_duration', FILTER_VALIDATE_INT) ?: 30;
    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    if (!$dentistId || !in_array($day, $days, true) || !preg_match('/^\d{2}:\d{2}$/', $open) || !preg_match('/^\d{2}:\d{2}$/', $close) || $open >= $close || $duration < 15) { flash_set('error', 'Please enter a valid clinician, day and appointment times.'); }
    else { $save = $pdo->prepare('INSERT INTO doctor_schedules (dentist_id, day_of_week, opening_time, closing_time, is_open, appointment_duration) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE opening_time = VALUES(opening_time), closing_time = VALUES(closing_time), is_open = VALUES(is_open), appointment_duration = VALUES(appointment_duration)'); $save->execute([$dentistId, $day, $open, $close, isset($_POST['is_open']) ? 1 : 0, $duration]); flash_set('success', 'Schedule saved.'); }
    redirect('admin/schedules.php');
}
$dentists = $pdo->query('SELECT id, name FROM dentists ORDER BY name')->fetchAll();
$schedules = $pdo->query("SELECT ds.*, d.name AS dentist_name FROM doctor_schedules ds JOIN dentists d ON d.id = ds.dentist_id ORDER BY d.name, FIELD(ds.day_of_week, 'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')")->fetchAll();
$adminTitle = 'Schedules';
require __DIR__ . '/_header.php';
?>
<div class="admin-page-heading"><div><span class="admin-kicker">Availability</span><h1>Schedules.</h1><p class="muted">Set the working hours used to generate live appointment times.</p></div></div><section class="admin-card"><h2>Set clinician availability</h2><form method="post"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><div class="form-grid"><div class="form-group"><label>Clinician</label><select class="form-control" name="dentist_id"><?php foreach ($dentists as $dentist): ?><option value="<?= (int) $dentist['id'] ?>"><?= e($dentist['name']) ?></option><?php endforeach; ?></select></div><div class="form-group"><label>Day</label><select class="form-control" name="day_of_week"><?php foreach (['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'] as $day): ?><option><?= e($day) ?></option><?php endforeach; ?></select></div><div class="form-group"><label>Opening time</label><input class="form-control" type="time" name="opening_time" value="10:00"></div><div class="form-group"><label>Closing time</label><input class="form-control" type="time" name="closing_time" value="20:00"></div><div class="form-group"><label>Appointment duration</label><select class="form-control" name="appointment_duration"><option value="15">15 minutes</option><option value="30" selected>30 minutes</option><option value="45">45 minutes</option><option value="60">60 minutes</option></select></div><div class="form-group"><label style="padding-top:27px"><input type="checkbox" name="is_open" checked> Available for bookings</label></div></div><button class="button button-primary" type="submit">Save availability</button></form></section><section class="admin-card table-card" style="padding:0;margin-top:20px"><div class="table-wrap"><table class="data-table"><thead><tr><th>Clinician</th><th>Day</th><th>Hours</th><th>Duration</th><th>Available</th></tr></thead><tbody><?php foreach ($schedules as $schedule): ?><tr><td><?= e($schedule['dentist_name']) ?></td><td><?= e($schedule['day_of_week']) ?></td><td><?= e(substr($schedule['opening_time'], 0, 5)) ?>–<?= e(substr($schedule['closing_time'], 0, 5)) ?></td><td><?= (int) $schedule['appointment_duration'] ?> min</td><td><?= $schedule['is_open'] ? 'Yes' : 'No' ?></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php require __DIR__ . '/_footer.php'; ?>
