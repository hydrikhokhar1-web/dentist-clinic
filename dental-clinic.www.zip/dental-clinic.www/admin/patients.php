<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
require_admin();
if (is_post()) {
    verify_csrf();
    $patientId = filter_input(INPUT_POST, 'patient_id', FILTER_VALIDATE_INT) ?: 0;
    if ($patientId) { $delete = $pdo->prepare('DELETE FROM users WHERE id = ?'); $delete->execute([$patientId]); flash_set($delete->rowCount() ? 'success' : 'warning', $delete->rowCount() ? 'Patient record deleted. Appointments remain as clinic records.' : 'Patient record not found.'); }
    redirect('admin/patients.php');
}
$search = trim((string) ($_GET['q'] ?? ''));
$statement = $pdo->prepare('SELECT u.*, COUNT(a.id) AS appointment_count FROM users u LEFT JOIN appointments a ON a.user_id = u.id WHERE u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? GROUP BY u.id ORDER BY u.created_at DESC');
$statement->execute(['%' . $search . '%', '%' . $search . '%', '%' . $search . '%']);
$patients = $statement->fetchAll();
$adminTitle = 'Patients';
require __DIR__ . '/_header.php';
?>
<div class="admin-page-heading"><div><span class="admin-kicker">Patient directory</span><h1>Patients.</h1><p class="muted">Review registered patient profiles and their booking activity.</p></div></div><form class="admin-card admin-form-toolbar" method="get"><div class="form-group"><label for="q">Search patients</label><input class="form-control" id="q" name="q" value="<?= e($search) ?>" placeholder="Name, email or phone"></div><button class="button button-outline" type="submit">Search</button></form><section class="admin-card table-card" style="padding:0"><div class="table-wrap"><table class="data-table"><thead><tr><th>Patient</th><th>Contact</th><th>Joined</th><th>Appointments</th><th></th></tr></thead><tbody><?php foreach ($patients as $patient): ?><tr><td><strong><?= e($patient['full_name']) ?></strong></td><td><?= e($patient['email']) ?><br><small><?= e($patient['phone']) ?></small></td><td><?= e(date('d M Y', strtotime($patient['created_at']))) ?></td><td><?= (int) $patient['appointment_count'] ?></td><td><form method="post" onsubmit="return confirm('Delete this patient profile? Appointment history will be retained without a patient account.');"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><input type="hidden" name="patient_id" value="<?= (int) $patient['id'] ?>"><button class="button button-danger" type="submit">Delete</button></form></td></tr><?php endforeach; ?></tbody></table></div><?php if (!$patients): ?><div class="empty-state"><i class="fa-regular fa-user"></i><p>No patient records found.</p></div><?php endif; ?></section>
<?php require __DIR__ . '/_footer.php'; ?>
