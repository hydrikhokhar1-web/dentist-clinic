<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
require_admin();
$fields = ['clinic_name' => 'Clinic name', 'phone' => 'Phone', 'email' => 'Email', 'address' => 'Address', 'opening_hours' => 'Opening hours', 'emergency_number' => 'Emergency number', 'facebook_url' => 'Facebook URL', 'instagram_url' => 'Instagram URL', 'whatsapp_url' => 'WhatsApp URL'];
if (is_post()) {
    verify_csrf();
    $save = $pdo->prepare('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
    foreach ($fields as $key => $_label) { $save->execute([$key, trim((string) ($_POST['settings'][$key] ?? ''))]); }
    flash_set('success', 'Studio settings updated.');
    redirect('admin/settings.php');
}
$adminTitle = 'Settings';
require __DIR__ . '/_header.php';
?>
<div class="admin-page-heading"><div><span class="admin-kicker">Studio settings</span><h1>Settings.</h1><p class="muted">Update clinic details used throughout the website.</p></div></div><section class="admin-card" style="max-width:860px"><form method="post"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><div class="form-grid"><?php foreach ($fields as $key => $label): ?><div class="form-group"><label for="<?= e($key) ?>"><?= e($label) ?></label><input class="form-control" id="<?= e($key) ?>" name="settings[<?= e($key) ?>]" value="<?= e(setting($pdo, $key)) ?>"></div><?php endforeach; ?></div><button class="button button-primary" type="submit">Save settings</button></form></section>
<?php require __DIR__ . '/_footer.php'; ?>
