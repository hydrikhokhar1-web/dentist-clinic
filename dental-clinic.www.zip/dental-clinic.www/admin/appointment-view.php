<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
require_admin();
$appointmentId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$statement = $pdo->prepare('SELECT a.*, d.name AS dentist_name, s.name AS service_name FROM appointments a JOIN dentists d ON d.id = a.dentist_id JOIN services s ON s.id = a.service_id WHERE a.id = ?');
$statement->execute([$appointmentId]);
$appointment = $statement->fetch();
if (!$appointment) { flash_set('warning', 'That appointment was not found.'); redirect('admin/appointments.php'); }
$adminTitle = 'Appointment details';
require __DIR__ . '/_header.php';
?>
<div class="admin-page-heading"><div><span class="admin-kicker">Appointment #<?= (int) $appointment['id'] ?></span><h1><?= e($appointment['patient_name']) ?></h1></div><a class="button button-outline" href="<?= app_url('admin/appointments.php') ?>">Back to appointments</a></div><section class="admin-card" style="max-width:850px"><div class="detail-meta"><div><span>Clinician</span><strong><?= e($appointment['dentist_name']) ?></strong></div><div><span>Service</span><strong><?= e($appointment['service_name']) ?></strong></div><div><span>When</span><strong><?= e(date('d M Y · g:i A', strtotime($appointment['appointment_date'] . ' ' . $appointment['appointment_time']))) ?></strong></div><div><span>Status</span><strong><span class="status <?= e(status_class($appointment['status'])) ?>"><?= e($appointment['status']) ?></span></strong></div></div><p><strong>Contact</strong><br><?= e($appointment['email']) ?> · <?= e($appointment['phone']) ?></p><p><strong>Patient note</strong><br><?= $appointment['message'] ? nl2br(e($appointment['message'])) : '—' ?></p></section>
<?php require __DIR__ . '/_footer.php'; ?>
