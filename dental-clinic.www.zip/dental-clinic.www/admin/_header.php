<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
require_admin();
$adminUser = current_admin($pdo);
if (!$adminUser) { unset($_SESSION['admin_id']); redirect('admin/login.php'); }
$adminPage = basename($_SERVER['PHP_SELF'] ?? '');
$adminTitle = $adminTitle ?? 'Admin dashboard';
$adminNav = [
    'dashboard.php' => ['Dashboard', 'fa-chart-pie'], 'appointments.php' => ['Appointments', 'fa-calendar-check'],
    'patients.php' => ['Patients', 'fa-users'], 'doctors.php' => ['Clinicians', 'fa-user-doctor'],
    'services.php' => ['Services', 'fa-tooth'], 'fees.php' => ['Fees', 'fa-tags'],
    'schedules.php' => ['Schedules', 'fa-clock'], 'messages.php' => ['Messages', 'fa-envelope'],
    'reviews.php' => ['Reviews', 'fa-star'], 'settings.php' => ['Settings', 'fa-sliders']
];
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?= e($adminTitle) ?> | Nura Admin</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"><link rel="stylesheet" href="<?= app_url('assets/css/style.css') ?>"><link rel="stylesheet" href="<?= app_url('assets/css/admin.css') ?>"></head><body class="admin-body"><div class="admin-shell"><aside class="admin-sidebar"><a class="wordmark wordmark-light" href="<?= app_url('admin/dashboard.php') ?>"><span class="wordmark-symbol"><i class="fa-solid fa-tooth"></i></span><span>NURA<small>ADMIN STUDIO</small></span></a><nav><?php foreach ($adminNav as $file => [$label, $icon]): ?><a class="<?= $adminPage === $file ? 'active' : '' ?>" href="<?= app_url('admin/' . $file) ?>"><i class="fa-solid <?= e($icon) ?>"></i><span><?= e($label) ?></span></a><?php endforeach; ?><a href="<?= app_url('admin/logout.php') ?>"><i class="fa-solid fa-arrow-right-from-bracket"></i><span>Sign out</span></a></nav></aside><div class="admin-main"><header class="admin-top"><span class="admin-title">Nura Dental Studio · Management</span><span class="admin-user"><i class="fa-regular fa-user"></i> <?= e($adminUser['full_name']) ?> · <?= date('d M Y') ?></span></header><div class="admin-content">
<?php if ($alert = flash_get()): ?><div class="site-alert site-alert-<?= e($alert['type']) ?>" style="margin:0 0 22px"><i class="fa-solid fa-circle-info"></i><?= e($alert['message']) ?></div><?php endif; ?>
