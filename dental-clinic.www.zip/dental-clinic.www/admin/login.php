<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
if (!empty($_SESSION['admin_id'])) { redirect('admin/dashboard.php'); }
if (is_post()) {
    verify_csrf();
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $statement = $pdo->prepare('SELECT id, password_hash FROM admins WHERE email = ? LIMIT 1');
    $statement->execute([$email]);
    $admin = $statement->fetch();
    if ($admin && password_verify($password, $admin['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['admin_id'] = (int) $admin['id'];
        flash_set('success', 'Welcome to the Nura management studio.');
        redirect('admin/dashboard.php');
    }
    flash_set('error', 'We could not sign you in with those details.');
}
$alert = flash_get();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Admin sign in | Nura Dental Studio</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"><link rel="stylesheet" href="../assets/css/style.css"></head><body><main class="auth-page"><aside class="auth-aside"><a class="wordmark wordmark-light" href="<?= app_url() ?>"><span class="wordmark-symbol"><i class="fa-solid fa-tooth"></i></span><span>NURA<small>ADMIN STUDIO</small></span></a><div><span class="eyebrow" style="color:#d7b97d">Management portal</span><h1>Make every patient interaction count.</h1><p>Manage appointments, clinic content and the team’s daily workflow from one clear dashboard.</p></div><small>Restricted access · Nura Dental Studio</small></aside><section class="auth-main"><div class="auth-box"><a class="wordmark" href="<?= app_url() ?>"><span class="wordmark-symbol"><i class="fa-solid fa-tooth"></i></span><span>NURA<small>ADMIN STUDIO</small></span></a><h1>Admin sign in.</h1><p>Use your authorised clinic account to continue.</p><?php if ($alert): ?><div class="site-alert site-alert-<?= e($alert['type']) ?>"><i class="fa-solid fa-circle-exclamation"></i><?= e($alert['message']) ?></div><?php endif; ?><form method="post"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><div class="form-group"><label for="email">Email address</label><input class="form-control" id="email" type="email" name="email" autocomplete="email" required></div><div class="form-group"><label for="password">Password</label><input class="form-control" id="password" type="password" name="password" autocomplete="current-password" required></div><button class="button button-primary" type="submit">Sign in securely <i class="fa-solid fa-arrow-right"></i></button></form></div></section></main></body></html>
