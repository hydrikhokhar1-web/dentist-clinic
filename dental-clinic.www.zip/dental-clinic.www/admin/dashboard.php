<?php
$adminTitle = 'Dashboard';
require __DIR__ . '/_header.php';
$metrics = [
    'Total patients' => (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(),
    'Total doctors' => (int) $pdo->query('SELECT COUNT(*) FROM dentists')->fetchColumn(),
    'Total appointments' => (int) $pdo->query('SELECT COUNT(*) FROM appointments')->fetchColumn(),
    'Pending appointments' => (int) $pdo->query("SELECT COUNT(*) FROM appointments WHERE status = 'Pending'")->fetchColumn(),
    'Today’s appointments' => (int) $pdo->query('SELECT COUNT(*) FROM appointments WHERE appointment_date = CURDATE()')->fetchColumn(),
    'Total services' => (int) $pdo->query('SELECT COUNT(*) FROM services')->fetchColumn(),
];
$recent = $pdo->query('SELECT a.*, d.name AS dentist_name, s.name AS service_name FROM appointments a JOIN dentists d ON d.id = a.dentist_id JOIN services s ON s.id = a.service_id ORDER BY a.created_at DESC LIMIT 7')->fetchAll();
$statuses = $pdo->query("SELECT status, COUNT(*) AS total FROM appointments GROUP BY status ORDER BY total DESC")->fetchAll();
?>
<div class="admin-page-heading"><div><span class="admin-kicker">Clinic overview</span><h1>Good morning, <?= e(explode(' ', $adminUser['full_name'])[0]) ?>.</h1></div><a class="button button-primary" href="<?= app_url('admin/appointments.php') ?>">Manage appointments</a></div><section class="admin-metric-grid"><?php foreach ($metrics as $label => $value): ?><article class="admin-metric"><span><?= e($label) ?></span><strong><?= $value ?></strong></article><?php endforeach; ?></section><section class="admin-layout"><article class="admin-card"><h2>Recent appointment activity</h2><?php if ($recent): ?><div class="table-wrap"><table class="data-table"><thead><tr><th>Patient</th><th>Visit</th><th>Date</th><th>Status</th></tr></thead><tbody><?php foreach ($recent as $appointment): ?><tr><td><?= e($appointment['patient_name']) ?></td><td><?= e($appointment['dentist_name']) ?><br><small><?= e($appointment['service_name']) ?></small></td><td><?= e(date('d M', strtotime($appointment['appointment_date']))) ?></td><td><span class="status <?= e(status_class($appointment['status'])) ?>"><?= e($appointment['status']) ?></span></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><div class="empty-state"><i class="fa-regular fa-calendar"></i><p>No appointments yet.</p></div><?php endif; ?></article><aside class="admin-card"><h2>Appointment status</h2><?php if ($statuses): ?><?php foreach ($statuses as $status): ?><div class="price-line"><span><?= e($status['status']) ?></span><strong><?= (int) $status['total'] ?></strong></div><?php endforeach; ?><?php else: ?><p class="muted">Status data will appear once patients begin booking.</p><?php endif; ?></aside></section>
<?php require __DIR__ . '/_footer.php'; ?>
