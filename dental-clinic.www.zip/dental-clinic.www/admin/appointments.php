<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
require_admin();
if (is_post()) {
    verify_csrf();
    $appointmentId = filter_input(INPUT_POST, 'appointment_id', FILTER_VALIDATE_INT) ?: 0;
    $status = (string) ($_POST['status'] ?? '');
    $validStatuses = ['Pending', 'Confirmed', 'Completed', 'Cancelled', 'Rejected'];
    if ($appointmentId && in_array($status, $validStatuses, true)) {
        $update = $pdo->prepare('UPDATE appointments SET status = ? WHERE id = ?');
        $update->execute([$status, $appointmentId]);
        flash_set('success', 'Appointment status updated.');
    } else { flash_set('error', 'The appointment update was not valid.'); }
    redirect('admin/appointments.php');
}
$search = trim((string) ($_GET['q'] ?? ''));
$statement = $pdo->prepare('SELECT a.*, d.name AS dentist_name, s.name AS service_name FROM appointments a JOIN dentists d ON d.id = a.dentist_id JOIN services s ON s.id = a.service_id WHERE a.patient_name LIKE ? OR a.email LIKE ? ORDER BY a.appointment_date DESC, a.appointment_time DESC');
$statement->execute(['%' . $search . '%', '%' . $search . '%']);
$appointments = $statement->fetchAll();
$adminTitle = 'Appointments';
require __DIR__ . '/_header.php';
?>
<div class="admin-page-heading"><div><span class="admin-kicker">Patient visits</span><h1>Appointments.</h1><p class="muted">Confirm, complete or update every booking from one place.</p></div></div><form class="admin-card admin-form-toolbar" method="get"><div class="form-group"><label for="q">Search patient or email</label><input class="form-control" id="q" name="q" value="<?= e($search) ?>" placeholder="Start typing a name or email"></div><button class="button button-outline" type="submit">Search</button></form><section class="admin-card table-card" style="padding:0"><div class="table-wrap"><table class="data-table"><thead><tr><th>Patient</th><th>Visit</th><th>Date & time</th><th>Note</th><th>Status</th><th>Update</th></tr></thead><tbody><?php foreach ($appointments as $appointment): ?><tr><td><strong><?= e($appointment['patient_name']) ?></strong><br><small><?= e($appointment['email']) ?><br><?= e($appointment['phone']) ?></small></td><td><?= e($appointment['dentist_name']) ?><br><small><?= e($appointment['service_name']) ?></small></td><td><?= e(date('d M Y', strtotime($appointment['appointment_date']))) ?><br><small><?= e(date('g:i A', strtotime($appointment['appointment_time']))) ?></small></td><td><?= e($appointment['message'] ?: '—') ?></td><td><span class="status <?= e(status_class($appointment['status'])) ?>"><?= e($appointment['status']) ?></span></td><td><form method="post" class="admin-table-actions"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><input type="hidden" name="appointment_id" value="<?= (int) $appointment['id'] ?>"><select class="form-control" name="status" aria-label="Appointment status"><?php foreach (['Pending', 'Confirmed', 'Completed', 'Cancelled', 'Rejected'] as $status): ?><option <?= $appointment['status'] === $status ? 'selected' : '' ?>><?= e($status) ?></option><?php endforeach; ?></select><button class="button button-primary" type="submit">Save</button></form></td></tr><?php endforeach; ?></tbody></table></div><?php if (!$appointments): ?><div class="empty-state"><i class="fa-regular fa-calendar"></i><p>No appointments match your search.</p></div><?php endif; ?></section>
<?php require __DIR__ . '/_footer.php'; ?>
