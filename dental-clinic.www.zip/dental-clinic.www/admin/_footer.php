</div></div></div>
<script src="<?= app_url('assets/js/script.js') ?>"></script>
</body></html>
