<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
require_admin();
if (is_post()) {
    verify_csrf();
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT) ?: 0;
    $fields = ['name', 'qualification', 'specialization', 'experience', 'biography', 'working_days', 'working_hours', 'image', 'email', 'phone'];
    $data = [];
    foreach ($fields as $field) { $data[$field] = trim((string) ($_POST[$field] ?? '')); }
    $fee = filter_input(INPUT_POST, 'consultation_fee', FILTER_VALIDATE_FLOAT);
    if (!$id || !$data['name'] || !$data['qualification'] || !$data['specialization'] || !$data['image'] || $fee === false || $fee < 0) { flash_set('error', 'Please complete all required clinician details with a valid consultation fee.'); }
    else { $update = $pdo->prepare('UPDATE dentists SET name = ?, qualification = ?, specialization = ?, experience = ?, consultation_fee = ?, biography = ?, working_days = ?, working_hours = ?, image = ?, email = ?, phone = ? WHERE id = ?'); $update->execute([$data['name'], $data['qualification'], $data['specialization'], $data['experience'], $fee, $data['biography'], $data['working_days'], $data['working_hours'], $data['image'], $data['email'] ?: null, $data['phone'] ?: null, $id]); flash_set('success', 'Clinician profile updated.'); }
    redirect('admin/doctors.php?id=' . $id);
}
$doctorId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$doctors = $pdo->query('SELECT * FROM dentists ORDER BY id')->fetchAll();
$editing = null;
foreach ($doctors as $doctor) { if ((int) $doctor['id'] === $doctorId) { $editing = $doctor; break; } }
$adminTitle = 'Clinicians';
require __DIR__ . '/_header.php';
?>
<div class="admin-page-heading"><div><span class="admin-kicker">Clinical team</span><h1>Clinicians.</h1><p class="muted">The six clinician profiles shown on the public website.</p></div></div><section class="admin-card table-card" style="padding:0"><div class="table-wrap"><table class="data-table"><thead><tr><th>Clinician</th><th>Specialisation</th><th>Consultation</th><th></th></tr></thead><tbody><?php foreach ($doctors as $doctor): ?><tr><td><?= e($doctor['name']) ?></td><td><?= e($doctor['specialization']) ?></td><td><?= money($doctor['consultation_fee']) ?></td><td><a class="button button-outline" href="<?= app_url('admin/doctors.php?id=' . (int) $doctor['id']) ?>">Edit profile</a></td></tr><?php endforeach; ?></tbody></table></div></section><?php if ($editing): ?><section class="admin-card" style="margin-top:20px"><h2>Edit <?= e($editing['name']) ?></h2><form method="post"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><input type="hidden" name="id" value="<?= (int) $editing['id'] ?>"><div class="form-grid"><div class="form-group"><label>Name *</label><input class="form-control" name="name" value="<?= e($editing['name']) ?>" required></div><div class="form-group"><label>Qualification *</label><input class="form-control" name="qualification" value="<?= e($editing['qualification']) ?>" required></div><div class="form-group"><label>Specialisation *</label><input class="form-control" name="specialization" value="<?= e($editing['specialization']) ?>" required></div><div class="form-group"><label>Experience</label><input class="form-control" name="experience" value="<?= e($editing['experience']) ?>"></div><div class="form-group"><label>Consultation fee *</label><input class="form-control" type="number" min="0" name="consultation_fee" value="<?= e((string) $editing['consultation_fee']) ?>" required></div><div class="form-group"><label>Image URL *</label><input class="form-control" name="image" value="<?= e($editing['image']) ?>" required></div><div class="form-group"><label>Working days</label><input class="form-control" name="working_days" value="<?= e($editing['working_days']) ?>"></div><div class="form-group"><label>Working hours</label><input class="form-control" name="working_hours" value="<?= e($editing['working_hours']) ?>"></div><div class="form-group"><label>Email</label><input class="form-control" name="email" value="<?= e($editing['email'] ?? '') ?>"></div><div class="form-group"><label>Phone</label><input class="form-control" name="phone" value="<?= e($editing['phone'] ?? '') ?>"></div><div class="form-group full"><label>Biography</label><textarea class="form-control" name="biography"><?= e($editing['biography']) ?></textarea></div></div><button class="button button-primary" type="submit">Save clinician</button></form></section><?php endif; ?>
<?php require __DIR__ . '/_footer.php'; ?>
