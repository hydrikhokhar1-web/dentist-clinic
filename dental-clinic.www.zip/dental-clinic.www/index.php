<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';

$services = $pdo->query('SELECT id, name, description, fee, image FROM services ORDER BY id LIMIT 4')->fetchAll();
$doctors = $pdo->query('SELECT id, name, specialization, image FROM dentists ORDER BY id LIMIT 3')->fetchAll();
$testimonials = $pdo->query("SELECT r.rating, r.review, COALESCE(u.full_name, 'Nura patient') AS patient_name FROM reviews r LEFT JOIN users u ON u.id = r.user_id WHERE r.status = 'Approved' ORDER BY r.created_at DESC LIMIT 3")->fetchAll();
$pageTitle = 'Thoughtful care for every smile';
require __DIR__ . '/partials/header.php';
?>
<main>
    <section class="hero">
        <div class="container hero-grid">
            <div class="hero-copy reveal">
                <span class="eyebrow">Welcome to Nura</span>
                <h1>Thoughtful dentistry for a <em>beautifully healthy</em> smile.</h1>
                <p>Modern clinical expertise in a calm, considered setting. We make every visit feel clear, comfortable and entirely personal.</p>
                <div class="hero-actions"><a class="button button-primary" href="<?= app_url('appointment.php') ?>">Book an appointment <i class="fa-solid fa-arrow-right"></i></a><a class="button button-outline" href="<?= app_url('services.php') ?>">Explore our care</a></div>
                <p class="hero-note"><i class="fa-solid fa-sparkles"></i> New patients are always welcome.</p>
            </div>
            <div class="hero-visual reveal"><img src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&w=1200&q=88" alt="Dental clinician consulting with a patient"><div class="hero-card"><i class="fa-regular fa-calendar-check"></i><span><strong>Care on your terms</strong>Easy online booking and thoughtful follow-up.</span></div></div>
        </div>
    </section>

    <section class="intro-panel">
        <video data-fallback autoplay muted loop playsinline poster="https://images.unsplash.com/photo-1606265752439-1f18756aa2ec?auto=format&fit=crop&w=1400&q=85"><source src="assets/video/clinic-intro.mp4" type="video/mp4"></video>
        <div class="intro-fallback"></div>
        <div class="intro-content reveal"><span class="eyebrow">A gentler kind of visit</span><h2>Designed around how you want to feel.</h2><p>Our studio pairs clinically-led care with an unhurried, reassuring experience from arrival to aftercare.</p></div>
    </section>

    <section class="stats-band"><div class="container stats-grid"><div class="stat"><strong data-count="12" data-suffix="+">12+</strong><span>Years of collective care</span></div><div class="stat"><strong data-count="6">6</strong><span>Dedicated clinicians</span></div><div class="stat"><strong data-count="8">8</strong><span>Specialist treatment paths</span></div><div class="stat"><strong data-count="98" data-suffix="%">98%</strong><span>Patient recommendation</span></div></div></section>

    <section class="section"><div class="container story-grid"><div class="photo-stack reveal"><img src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=900&q=85" alt="Comfortable clinical setting"><img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=700&q=85" alt="Dental care consultation"></div><div class="reveal"><span class="eyebrow">Our approach</span><h2>Care that begins by listening.</h2><p class="muted">Every smile and every concern is different. We take time to understand your goals, explain your options without pressure, and build a plan that makes sense for you.</p><div class="check-grid"><span><i class="fa-solid fa-check"></i> Clear, honest guidance</span><span><i class="fa-solid fa-check"></i> Modern clinical tools</span><span><i class="fa-solid fa-check"></i> Comfort-first experience</span><span><i class="fa-solid fa-check"></i> Transparent treatment fees</span></div><a class="button button-outline" href="<?= app_url('about.php') ?>">Discover the studio</a></div></div></section>

    <section class="section section-muted"><div class="container"><div class="section-head reveal"><span class="eyebrow">Our care</span><h2>Everything your smile needs, thoughtfully delivered.</h2><p>From gentle preventative visits to advanced restorative treatment, our care is built around long-term wellbeing.</p></div><div class="service-grid">
        <?php foreach ($services as $service): ?>
            <article class="card service-card reveal"><div class="service-image"><img src="<?= e($service['image']) ?>" alt="<?= e($service['name']) ?>" loading="lazy"></div><div class="service-card-body"><h3><?= e($service['name']) ?></h3><p><?= e($service['description']) ?></p><a class="card-link" href="<?= app_url('service-details.php?id=' . (int) $service['id']) ?>">Explore treatment <i class="fa-solid fa-arrow-right"></i></a></div></article>
        <?php endforeach; ?>
    </div><p style="margin-top:30px"><a class="button button-outline" href="<?= app_url('services.php') ?>">View all care options</a></p></div></section>

    <section class="section"><div class="container"><div class="section-head reveal"><span class="eyebrow">Why Nura</span><h2>Clinical confidence, human warmth.</h2></div><div class="feature-grid"><article class="card feature reveal"><span class="feature-icon"><i class="fa-solid fa-stethoscope"></i></span><h3>Expert-led treatment</h3><p>Our clinicians bring focused experience and a commitment to continuing education to every treatment plan.</p></article><article class="card feature reveal"><span class="feature-icon"><i class="fa-solid fa-comments"></i></span><h3>Time to understand</h3><p>We keep consultations conversational, so you understand the choices before making any decisions.</p></article><article class="card feature reveal"><span class="feature-icon"><i class="fa-solid fa-shield-heart"></i></span><h3>Care that lasts</h3><p>We prioritise preventative habits and durable results to support your health beyond today’s appointment.</p></article></div></div></section>

    <section class="section section-muted"><div class="container"><div class="section-head reveal"><span class="eyebrow">Our clinicians</span><h2>Experienced hands. Reassuring care.</h2><p>Meet a team united by meticulous clinical work and a genuinely welcoming manner.</p></div><div class="doctors-grid">
        <?php foreach ($doctors as $doctor): ?>
            <article class="card doctor-card reveal"><div class="doctor-photo"><img src="<?= e($doctor['image']) ?>" alt="<?= e($doctor['name']) ?>" loading="lazy"></div><div class="doctor-info"><h3><?= e($doctor['name']) ?></h3><p><?= e($doctor['specialization']) ?></p><div class="doctor-actions"><a class="button button-outline" href="<?= app_url('doctor-details.php?id=' . (int) $doctor['id']) ?>">View profile</a><a class="button button-soft" href="<?= app_url('appointment.php?dentist=' . (int) $doctor['id']) ?>">Book</a></div></div></article>
        <?php endforeach; ?>
    </div></div></section>

    <section class="appointment-cta"><div class="container cta-content reveal"><div><span class="eyebrow">Your visit, made easy</span><h2>Ready to feel better about your next dental appointment?</h2></div><a class="button button-primary" href="<?= app_url('appointment.php') ?>">Book a visit <i class="fa-solid fa-arrow-right"></i></a></div></section>

    <section class="section"><div class="container"><div class="section-head reveal"><span class="eyebrow">Patient stories</span><h2>Kind words from our patients.</h2></div><div class="testimonial-grid"><?php foreach ($testimonials as $testimonial): ?><blockquote class="card quote-card reveal"><i class="fa-solid fa-quote-left"></i><p>“<?= e($testimonial['review']) ?>”</p><div class="quote-person"><span><?= str_repeat('★', (int) $testimonial['rating']) ?></span><?= e($testimonial['patient_name']) ?></div></blockquote><?php endforeach; ?></div></div></section>
</main>
<?php require __DIR__ . '/partials/footer.php'; ?>
