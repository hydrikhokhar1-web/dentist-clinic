<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';
if (!empty($_SESSION['user_id'])) { redirect('patient/dashboard.php'); }

if (is_post()) {
    verify_csrf();
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $statement = $pdo->prepare('SELECT id, password_hash FROM users WHERE email = ? LIMIT 1');
    $statement->execute([$email]);
    $user = $statement->fetch();
    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $user['id'];
        flash_set('success', 'Welcome back. Your patient portal is ready.');
        redirect('patient/dashboard.php');
    }
    flash_set('error', 'We could not sign you in with those details.');
}
$alert = flash_get();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Patient sign in | Nura Dental Studio</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"><link rel="stylesheet" href="assets/css/style.css"></head><body><main class="auth-page"><aside class="auth-aside"><a class="wordmark wordmark-light" href="<?= app_url() ?>"><span class="wordmark-symbol"><i class="fa-solid fa-tooth"></i></span><span>NURA<small>DENTAL STUDIO</small></span></a><div><span class="eyebrow" style="color:#d7b97d">Patient portal</span><h1>Your care, in one calm place.</h1><p>View appointments, update your details and keep up with your treatment journey.</p></div><small>Thoughtful dentistry, from first visit onwards.</small></aside><section class="auth-main"><div class="auth-box"><a class="wordmark" href="<?= app_url() ?>"><span class="wordmark-symbol"><i class="fa-solid fa-tooth"></i></span><span>NURA<small>DENTAL STUDIO</small></span></a><h1>Welcome back.</h1><p>Sign in to view your appointments and profile.</p><?php if ($alert): ?><div class="site-alert site-alert-<?= e($alert['type']) ?>"><i class="fa-solid fa-circle-exclamation"></i><?= e($alert['message']) ?></div><?php endif; ?><form method="post"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><div class="form-group"><label for="email">Email address</label><input class="form-control" id="email" type="email" name="email" autocomplete="email" required></div><div class="form-group"><label for="password">Password</label><input class="form-control" id="password" type="password" name="password" autocomplete="current-password" required></div><button class="button button-primary" type="submit">Sign in <i class="fa-solid fa-arrow-right"></i></button></form><p class="auth-foot">New to Nura? <a href="<?= app_url('register.php') ?>">Create a patient account</a></p></div></section></main></body></html>
