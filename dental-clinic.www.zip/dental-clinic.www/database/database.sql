CREATE DATABASE IF NOT EXISTS dental_clinic CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dental_clinic;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS appointments;
DROP TABLE IF EXISTS doctor_schedules;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS contact_messages;
DROP TABLE IF EXISTS fees;
DROP TABLE IF EXISTS services;
DROP TABLE IF EXISTS dentists;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS admins;
DROP TABLE IF EXISTS settings;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL UNIQUE,
    phone VARCHAR(40) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE admins (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE dentists (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL UNIQUE,
    qualification VARCHAR(180) NOT NULL,
    specialization VARCHAR(180) NOT NULL,
    experience VARCHAR(80) NOT NULL,
    consultation_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
    biography TEXT NOT NULL,
    working_days VARCHAR(180) NOT NULL,
    working_hours VARCHAR(100) NOT NULL,
    image VARCHAR(500) NOT NULL,
    email VARCHAR(160) DEFAULT NULL,
    phone VARCHAR(40) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE services (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL UNIQUE,
    description TEXT NOT NULL,
    details TEXT NOT NULL,
    fee DECIMAL(10,2) NOT NULL DEFAULT 0,
    duration VARCHAR(80) NOT NULL,
    image VARCHAR(500) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE fees (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(100) NOT NULL,
    name VARCHAR(150) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    duration VARCHAR(80) DEFAULT NULL,
    description TEXT DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_fees_category (category)
) ENGINE=InnoDB;

CREATE TABLE doctor_schedules (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    dentist_id INT UNSIGNED NOT NULL,
    day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
    opening_time TIME NOT NULL,
    closing_time TIME NOT NULL,
    is_open TINYINT(1) NOT NULL DEFAULT 1,
    appointment_duration SMALLINT UNSIGNED NOT NULL DEFAULT 30,
    UNIQUE KEY unique_doctor_day (dentist_id, day_of_week),
    CONSTRAINT fk_schedule_dentist FOREIGN KEY (dentist_id) REFERENCES dentists(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE appointments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED DEFAULT NULL,
    patient_name VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL,
    phone VARCHAR(40) NOT NULL,
    dentist_id INT UNSIGNED NOT NULL,
    service_id INT UNSIGNED NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    message TEXT DEFAULT NULL,
    status ENUM('Pending','Confirmed','Completed','Cancelled','Rejected') NOT NULL DEFAULT 'Pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_dentist_slot (dentist_id, appointment_date, appointment_time),
    INDEX idx_appointments_user (user_id),
    INDEX idx_appointments_date_status (appointment_date, status),
    CONSTRAINT fk_appointment_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_appointment_dentist FOREIGN KEY (dentist_id) REFERENCES dentists(id) ON DELETE RESTRICT,
    CONSTRAINT fk_appointment_service FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE reviews (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED DEFAULT NULL,
    rating TINYINT UNSIGNED NOT NULL,
    review TEXT NOT NULL,
    status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_review_rating CHECK (rating BETWEEN 1 AND 5),
    CONSTRAINT fk_review_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE contact_messages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL,
    phone VARCHAR(40) DEFAULT NULL,
    subject VARCHAR(180) DEFAULT NULL,
    message TEXT NOT NULL,
    status ENUM('New','Read','Archived') NOT NULL DEFAULT 'New',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_message_status (status)
) ENGINE=InnoDB;

CREATE TABLE settings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT NOT NULL
) ENGINE=InnoDB;

INSERT INTO admins (full_name, email, password_hash) VALUES
('Nura System Administrator', 'admin@nura.dental', '$2y$10$2NPK4CJRQncxgNecQS/zd.L1yLctIcSHyz1kxwXmvoVlgxrJNajAW');

INSERT INTO dentists (name, qualification, specialization, experience, consultation_fee, biography, working_days, working_hours, image, email, phone) VALUES
('Dr. Raffay Arslan', 'BDS, FCPS (Operative Dentistry)', 'Restorative & Implant Dentistry', '12 years', 3000, 'Dr. Raffay combines precise restorative planning with a calm, conversational approach. His focus is preserving natural teeth and designing reliable, long-lasting restorations.', 'Monday–Saturday', '10:00 AM – 8:00 PM', 'https://images.unsplash.com/photo-1612349317150-e88e6ff1fcc2?auto=format&fit=crop&w=900&q=85', 'raffay@nura.dental', '+92 300 123 4561'),
('Dr. Muhammad Ali', 'BDS, MDS (Orthodontics)', 'Orthodontics & Smile Alignment', '10 years', 2800, 'Dr. Muhammad creates practical, confidence-building orthodontic plans for adults and teens, with careful progress monitoring at every stage.', 'Monday–Saturday', '10:00 AM – 8:00 PM', 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&w=900&q=85', 'muhammad@nura.dental', '+92 300 123 4562'),
('Dr. Basit Ali', 'BDS, FCPS (Endodontics)', 'Root Canal & Microsurgery', '9 years', 2800, 'Dr. Basit is dedicated to gentle endodontic treatment. He uses detailed diagnosis and clear aftercare guidance to make complex care feel manageable.', 'Monday–Saturday', '10:00 AM – 8:00 PM', 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=900&q=85', 'basit@nura.dental', '+92 300 123 4563'),
('Dr. Asif', 'BDS, MSc (Prosthodontics)', 'Crowns, Bridges & Aesthetic Rehabilitation', '11 years', 3000, 'Dr. Asif works at the intersection of function and aesthetics, creating crowns, bridges and rehabilitation plans that feel as natural as they look.', 'Monday–Saturday', '10:00 AM – 8:00 PM', 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=900&q=85', 'asif@nura.dental', '+92 300 123 4564'),
('Dr. Saad', 'BDS, PGCert (Paediatric Dentistry)', 'Family & Paediatric Dentistry', '8 years', 2200, 'Dr. Saad makes dental care approachable for every member of the family, especially young patients experiencing the clinic for the first time.', 'Monday–Saturday', '10:00 AM – 8:00 PM', 'https://images.unsplash.com/photo-1584982751601-97dcc096659c?auto=format&fit=crop&w=900&q=85', 'saad@nura.dental', '+92 300 123 4565'),
('Dr. Ubaid', 'BDS, MFDS', 'Cosmetic & Preventive Dentistry', '7 years', 2500, 'Dr. Ubaid takes a preventative, minimally invasive approach to cosmetic care, helping patients build healthier smiles without unnecessary treatment.', 'Monday–Saturday', '10:00 AM – 8:00 PM', 'https://images.unsplash.com/photo-1618498082410-b4aa22193b38?auto=format&fit=crop&w=900&q=85', 'ubaid@nura.dental', '+92 300 123 4566');

INSERT INTO services (name, description, details, fee, duration, image) VALUES
('Dental Checkup', 'A thoughtful starting point for your oral health.', 'Your clinician will discuss your concerns, assess your teeth and gums, and create an honest, tailored care plan.', 2000, '30 minutes', 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&w=900&q=85'),
('Teeth Cleaning', 'Professional cleaning for a fresher, healthier smile.', 'A gentle hygiene visit removes hardened plaque and helps protect your gums, with practical tips for your routine at home.', 3500, '45 minutes', 'https://images.unsplash.com/photo-1606265752439-1f18756aa2ec?auto=format&fit=crop&w=900&q=85'),
('Teeth Whitening', 'A brighter smile with clinician-guided treatment.', 'We first check that whitening is right for you, then use a professional protocol designed around comfort and natural-looking results.', 18000, '60 minutes', 'https://images.unsplash.com/photo-1609840114035-3c981b782dfe?auto=format&fit=crop&w=900&q=85'),
('Dental Implants', 'A confident, lasting solution for missing teeth.', 'From planning through restoration, implant treatment is carefully phased for long-term fit, function and gum health.', 55000, 'Multiple visits', 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=900&q=85'),
('Root Canal Treatment', 'Comfort-focused care to preserve your natural tooth.', 'We use modern diagnostics and careful treatment to address infection, relieve discomfort and protect your natural tooth.', 15000, '60–90 minutes', 'https://images.unsplash.com/photo-1609840113920-410d2b6cf1a3?auto=format&fit=crop&w=900&q=85'),
('Braces & Orthodontics', 'Structured smile alignment for every age.', 'Choose a treatment plan built around your bite, goals and lifestyle, with regular support throughout your alignment journey.', 85000, 'Long-term plan', 'https://images.unsplash.com/photo-1606811971618-4486d14f3f99?auto=format&fit=crop&w=900&q=85'),
('Pediatric Dentistry', 'Gentle, positive care for growing smiles.', 'A calm first visit, preventative support and child-friendly explanations help build a strong foundation for lifelong oral health.', 2500, '30 minutes', 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=900&q=85'),
('Cosmetic Dentistry', 'Thoughtful refinements that still look like you.', 'We listen first, then explore conservative aesthetic treatments that balance colour, proportion, function and confidence.', 12000, 'Varies', 'https://images.unsplash.com/photo-1598256989800-fe5f95da9787?auto=format&fit=crop&w=900&q=85');

INSERT INTO fees (category, name, price, duration, description) VALUES
('Preventive care', 'Dental Checkup', 2000, '30 min', 'Comprehensive oral health assessment'),
('Preventive care', 'Teeth Cleaning', 3500, '45 min', 'Professional hygiene treatment'),
('Cosmetic care', 'Teeth Whitening', 18000, '60 min', 'In-clinic whitening session'),
('Restorative care', 'Root Canal Treatment', 15000, '60–90 min', 'Starting fee; restoration is assessed separately'),
('Restorative care', 'Dental Implant', 55000, 'Multiple visits', 'Starting fee per implant'),
('Orthodontics', 'Braces & Orthodontics', 85000, 'Long-term', 'Starting treatment plan fee'),
('Family care', 'Pediatric Dentistry', 2500, '30 min', 'Child-focused consultation'),
('Cosmetic care', 'Cosmetic Dentistry', 12000, 'Varies', 'Initial aesthetic treatment planning');

INSERT INTO doctor_schedules (dentist_id, day_of_week, opening_time, closing_time, is_open, appointment_duration)
SELECT d.id, day_data.day_of_week, day_data.opening_time, day_data.closing_time, day_data.is_open, 30
FROM dentists d
CROSS JOIN (
    SELECT 'Monday' AS day_of_week, '10:00:00' AS opening_time, '20:00:00' AS closing_time, 1 AS is_open UNION ALL
    SELECT 'Tuesday', '10:00:00', '20:00:00', 1 UNION ALL
    SELECT 'Wednesday', '10:00:00', '20:00:00', 1 UNION ALL
    SELECT 'Thursday', '10:00:00', '20:00:00', 1 UNION ALL
    SELECT 'Friday', '10:00:00', '20:00:00', 1 UNION ALL
    SELECT 'Saturday', '10:00:00', '18:00:00', 1 UNION ALL
    SELECT 'Sunday', '10:00:00', '18:00:00', 0
) AS day_data;

INSERT INTO reviews (user_id, rating, review, status) VALUES
(NULL, 5, 'The team took the time to explain everything clearly. I felt completely at ease from the moment I arrived.', 'Approved'),
(NULL, 5, 'A calm, beautiful space and genuinely thoughtful care. My treatment plan felt practical and never rushed.', 'Approved'),
(NULL, 5, 'Booking was simple, the appointment was on time, and I left knowing exactly how to care for my smile.', 'Approved');

INSERT INTO settings (setting_key, setting_value) VALUES
('clinic_name', 'Nura Dental Studio'),
('phone', '+92 300 123 4567'),
('email', 'hello@nura.dental'),
('address', 'DHA Phase 5, Lahore, Pakistan'),
('opening_hours', 'Mon–Sat · 10:00 AM – 8:00 PM'),
('emergency_number', '+92 300 123 4567'),
('facebook_url', '#'),
('instagram_url', '#'),
('whatsapp_url', 'https://wa.me/923001234567');
