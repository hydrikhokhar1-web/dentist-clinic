<?php
$portalTitle = 'My appointments';
require __DIR__ . '/_header.php';
if (is_post()) {
    verify_csrf();
    $appointmentId = filter_input(INPUT_POST, 'appointment_id', FILTER_VALIDATE_INT) ?: 0;
    $cancel = $pdo->prepare("UPDATE appointments SET status = 'Cancelled' WHERE id = ? AND user_id = ? AND appointment_date >= CURDATE() AND status IN ('Pending', 'Confirmed')");
    $cancel->execute([$appointmentId, $portalUser['id']]);
    flash_set($cancel->rowCount() ? 'success' : 'warning', $cancel->rowCount() ? 'Your appointment has been cancelled.' : 'This appointment can no longer be cancelled online.');
    redirect('patient/appointments.php');
}
$statement = $pdo->prepare('SELECT a.*, d.name AS dentist_name, s.name AS service_name FROM appointments a JOIN dentists d ON d.id = a.dentist_id JOIN services s ON s.id = a.service_id WHERE a.user_id = ? ORDER BY a.appointment_date DESC, a.appointment_time DESC');
$statement->execute([$portalUser['id']]);
$appointments = $statement->fetchAll();
?>
<main class="portal-main"><div class="container"><div class="portal-heading"><div><span class="eyebrow">My care</span><h1>Appointments.</h1><p class="muted">Review each visit and its current confirmation status.</p></div><a class="button button-primary" href="<?= app_url('appointment.php') ?>">Book another visit</a></div><section class="card table-card"><?php if ($appointments): ?><div class="table-wrap"><table class="data-table"><thead><tr><th>Clinician</th><th>Treatment</th><th>Date & time</th><th>Status</th><th>Actions</th></tr></thead><tbody><?php foreach ($appointments as $appointment): ?><tr><td><?= e($appointment['dentist_name']) ?></td><td><?= e($appointment['service_name']) ?></td><td><?= e(date('d M Y · g:i A', strtotime($appointment['appointment_date'] . ' ' . $appointment['appointment_time']))) ?></td><td><span class="status <?= e(status_class($appointment['status'])) ?>"><?= e($appointment['status']) ?></span></td><td><div class="admin-table-actions"><a class="button button-outline" href="<?= app_url('patient/appointment-details.php?id=' . (int) $appointment['id']) ?>">Details</a><?php if (in_array($appointment['status'], ['Pending', 'Confirmed'], true) && $appointment['appointment_date'] >= date('Y-m-d')): ?><form method="post" onsubmit="return confirm('Cancel this appointment?');"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><input type="hidden" name="appointment_id" value="<?= (int) $appointment['id'] ?>"><button class="button button-danger" type="submit">Cancel</button></form><?php endif; ?></div></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><div class="empty-state"><i class="fa-regular fa-calendar"></i><p>You have no appointments yet.</p></div><?php endif; ?></section></div></main>
<?php require __DIR__ . '/_footer.php'; ?>
