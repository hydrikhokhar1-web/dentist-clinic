<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
require_patient();
$portalUser = current_user($pdo);
if (!$portalUser) { unset($_SESSION['user_id']); redirect('login.php'); }
$portalPage = basename($_SERVER['PHP_SELF'] ?? '');
$portalTitle = $portalTitle ?? 'Patient portal';
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?= e($portalTitle) ?> | Nura Dental Studio</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"><link rel="stylesheet" href="<?= app_url('assets/css/style.css') ?>"></head><body>
<header class="portal-top"><div class="container"><a class="wordmark wordmark-light" href="<?= app_url() ?>"><span class="wordmark-symbol"><i class="fa-solid fa-tooth"></i></span><span>NURA<small>PATIENT PORTAL</small></span></a><nav class="portal-nav"><a class="<?= $portalPage === 'dashboard.php' ? 'active' : '' ?>" href="<?= app_url('patient/dashboard.php') ?>">Dashboard</a><a class="<?= in_array($portalPage, ['appointments.php', 'appointment-details.php'], true) ? 'active' : '' ?>" href="<?= app_url('patient/appointments.php') ?>">Appointments</a><a class="<?= $portalPage === 'profile.php' ? 'active' : '' ?>" href="<?= app_url('patient/profile.php') ?>">Profile</a><a class="portal-mobile" href="<?= app_url('patient/logout.php') ?>" title="Sign out"><i class="fa-solid fa-arrow-right-from-bracket"></i></a></nav></div></header>
<?php if ($alert = flash_get()): ?><div class="container alert-wrap"><div class="site-alert site-alert-<?= e($alert['type']) ?>"><i class="fa-solid fa-circle-info"></i><?= e($alert['message']) ?></div></div><?php endif; ?>
