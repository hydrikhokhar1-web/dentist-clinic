<?php
$portalTitle = 'Appointment details';
require __DIR__ . '/_header.php';
$appointmentId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$statement = $pdo->prepare('SELECT a.*, d.name AS dentist_name, d.specialization, s.name AS service_name FROM appointments a JOIN dentists d ON d.id = a.dentist_id JOIN services s ON s.id = a.service_id WHERE a.id = ? AND a.user_id = ? LIMIT 1');
$statement->execute([$appointmentId, $portalUser['id']]);
$appointment = $statement->fetch();
if (!$appointment) { flash_set('warning', 'That appointment was not found.'); redirect('patient/appointments.php'); }
?>
<main class="portal-main"><div class="container"><div class="portal-heading"><div><span class="eyebrow">Appointment</span><h1>Your visit details.</h1></div><a class="button button-outline" href="<?= app_url('patient/appointments.php') ?>">Back to appointments</a></div><section class="card form-card" style="max-width:760px"><div class="detail-meta"><div><span>Clinician</span><strong><?= e($appointment['dentist_name']) ?></strong></div><div><span>Care</span><strong><?= e($appointment['service_name']) ?></strong></div><div><span>Date & time</span><strong><?= e(date('d M Y · g:i A', strtotime($appointment['appointment_date'] . ' ' . $appointment['appointment_time']))) ?></strong></div><div><span>Status</span><strong><span class="status <?= e(status_class($appointment['status'])) ?>"><?= e($appointment['status']) ?></span></strong></div></div><?php if ($appointment['message']): ?><p><strong>Your note</strong><br><?= nl2br(e($appointment['message'])) ?></p><?php endif; ?><p class="muted">If you need to make a change close to your appointment time, please call the studio directly.</p></section></div></main>
<?php require __DIR__ . '/_footer.php'; ?>
