<?php
$portalTitle = 'My profile';
require __DIR__ . '/_header.php';
if (is_post()) {
    verify_csrf();
    $name = trim((string) ($_POST['full_name'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    $phone = trim((string) ($_POST['phone'] ?? ''));
    $errors = [];
    if (mb_strlen($name) < 2 || mb_strlen($name) > 120) { $errors[] = 'Please enter your full name.'; }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors[] = 'Please enter a valid email address.'; }
    if (mb_strlen($phone) < 7 || mb_strlen($phone) > 40) { $errors[] = 'Please enter a valid phone number.'; }
    $newPassword = (string) ($_POST['new_password'] ?? '');
    if ($newPassword !== '' && strlen($newPassword) < 8) { $errors[] = 'Your new password must be at least 8 characters.'; }
    if (!$errors) { $exists = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id != ? LIMIT 1'); $exists->execute([$email, $portalUser['id']]); if ($exists->fetch()) { $errors[] = 'Another account already uses that email address.'; } }
    if ($errors) { flash_set('error', implode(' ', $errors)); } else { $sql = 'UPDATE users SET full_name = ?, email = ?, phone = ?' . ($newPassword !== '' ? ', password_hash = ?' : '') . ' WHERE id = ?'; $parameters = [$name, $email, $phone]; if ($newPassword !== '') { $parameters[] = password_hash($newPassword, PASSWORD_DEFAULT); } $parameters[] = $portalUser['id']; $update = $pdo->prepare($sql); $update->execute($parameters); flash_set('success', 'Your profile has been updated.'); redirect('patient/profile.php'); }
}
?>
<main class="portal-main"><div class="container"><div class="portal-heading"><div><span class="eyebrow">My profile</span><h1>Keep your details current.</h1><p class="muted">We use these details for appointment confirmations and clinic communication.</p></div></div><section class="card form-card" style="max-width:760px"><form method="post"><input type="hidden" name="_csrf" value="<?= csrf_token() ?>"><div class="form-grid"><div class="form-group"><label for="full_name">Full name</label><input class="form-control" id="full_name" name="full_name" value="<?= e($portalUser['full_name']) ?>" required></div><div class="form-group"><label for="email">Email address</label><input class="form-control" id="email" type="email" name="email" value="<?= e($portalUser['email']) ?>" required></div><div class="form-group"><label for="phone">Phone number</label><input class="form-control" id="phone" name="phone" value="<?= e($portalUser['phone']) ?>" required></div><div class="form-group"><label for="new_password">New password <small>(optional)</small></label><input class="form-control" id="new_password" type="password" name="new_password" minlength="8" autocomplete="new-password"></div></div><button class="button button-primary" type="submit">Save profile</button></form></section></div></main>
<?php require __DIR__ . '/_footer.php'; ?>
