<?php
$portalTitle = 'Patient dashboard';
require __DIR__ . '/_header.php';
$counts = ['Total appointments' => 0, 'Pending' => 0, 'Confirmed' => 0, 'Completed' => 0];
$countStatement = $pdo->prepare("SELECT status, COUNT(*) AS total FROM appointments WHERE user_id = ? GROUP BY status");
$countStatement->execute([$portalUser['id']]);
$total = 0;
foreach ($countStatement as $row) { $total += (int) $row['total']; if (array_key_exists($row['status'], $counts)) { $counts[$row['status']] = (int) $row['total']; } }
$counts['Total appointments'] = $total;
$upcoming = $pdo->prepare('SELECT a.*, d.name AS dentist_name, s.name AS service_name FROM appointments a JOIN dentists d ON d.id = a.dentist_id JOIN services s ON s.id = a.service_id WHERE a.user_id = ? ORDER BY a.appointment_date ASC, a.appointment_time ASC LIMIT 5');
$upcoming->execute([$portalUser['id']]);
$appointments = $upcoming->fetchAll();
?>
<main class="portal-main"><div class="container"><div class="portal-heading"><div><span class="eyebrow">Patient portal</span><h1>Hello, <?= e(explode(' ', $portalUser['full_name'])[0]) ?>.</h1><p class="muted">Here’s a clear view of your care at Nura.</p></div><a class="button button-primary" href="<?= app_url('appointment.php') ?>">Book a visit <i class="fa-solid fa-arrow-right"></i></a></div><section class="portal-stats"><?php foreach ($counts as $label => $count): ?><article class="card portal-stat"><span><?= e($label) ?></span><strong><?= $count ?></strong></article><?php endforeach; ?></section><section class="card table-card"><div class="table-card-header"><h2>Recent & upcoming appointments</h2><a class="card-link" href="<?= app_url('patient/appointments.php') ?>">View all</a></div><?php if ($appointments): ?><div class="table-wrap"><table class="data-table"><thead><tr><th>Clinician</th><th>Treatment</th><th>Date & time</th><th>Status</th><th></th></tr></thead><tbody><?php foreach ($appointments as $appointment): ?><tr><td><?= e($appointment['dentist_name']) ?></td><td><?= e($appointment['service_name']) ?></td><td><?= e(date('d M Y · g:i A', strtotime($appointment['appointment_date'] . ' ' . $appointment['appointment_time']))) ?></td><td><span class="status <?= e(status_class($appointment['status'])) ?>"><?= e($appointment['status']) ?></span></td><td><a class="card-link" href="<?= app_url('patient/appointment-details.php?id=' . (int) $appointment['id']) ?>">Details</a></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><div class="empty-state"><i class="fa-regular fa-calendar"></i><p>You have no appointments yet.</p><a class="button button-primary button-small" href="<?= app_url('appointment.php') ?>">Book your first visit</a></div><?php endif; ?></section></div></main>
<?php require __DIR__ . '/_footer.php'; ?>
