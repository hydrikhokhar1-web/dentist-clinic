<?php
require_once __DIR__ . '/../config/functions.php';
unset($_SESSION['user_id']);
session_regenerate_id(true);
flash_set('success', 'You have been signed out safely.');
redirect('index.php');
